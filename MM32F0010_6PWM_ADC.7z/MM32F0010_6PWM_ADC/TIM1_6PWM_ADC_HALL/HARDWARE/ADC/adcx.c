////////////////////////////////////////////////////////////////////////////////
/// @file    adcx.c
/// @author  AE TEAM
/// @brief   Output received data.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
// Define to prevent recursive inclusion
#define _ADCX_C_

// Files includes
#include "delay.h"
#include "adcx.h"

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Hardware_Abstract_Layer
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup ADCX
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup ADC_Exported_Functions
/// @{

uint16_t ADC_Buff[3] = {0};

////////////////////////////////////////////////////////////////////////////////
/// @brief  Set ADCn sample time.
/// @param  ADCn: where n can be 1, 2 to select the ADC peripheral.
/// @param  channel: the ADC channel to configure.
/// @param  sampleTime: the ADC Channel n Sample time to configure.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
static void ADCxSampleTimeConfig(ADC_TypeDef *ADCn, ADCSAM_TypeDef sampleTime)
{
    ADCn->CFGR &= ~ADC_CFGR_SAMCTL;
    ADCn->CFGR |= sampleTime;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  void ADC1ChannelInit(void)
/// @note
/// @param
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADC1ChannelInit(void)
{
    ADC_InitTypeDef ADC_InitStructure;
    NVIC_InitTypeDef NVIC_InitStruct;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1ENR_ADC1, ENABLE); //Enable ADC clock //Enable ADC clock
    RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOB, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOA, ENABLE);

    GPIO_StructInit(&GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1; //VBUS ISUM
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      //Output speed
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;          //GPIO mode
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15; //VSP
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    ADC_StructInit(&ADC_InitStructure);

    ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
    ADC_InitStructure.ADC_PRESCARE = ADC_PCLK2_PRESCARE_4; //ADC prescale factor   48M/4=12M
    ADC_InitStructure.ADC_Mode = ADC_CR_SCAN;              //Set ADC mode to continuous conversion mode
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right; //AD data right-justified
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC4;

    ADC_Init(ADC1, &ADC_InitStructure);

    ADCxSampleTimeConfig(ADC1, ADC_Samctl_28_5);

    ADC_ExternalTrigConvCmd(ADC1, ENABLE); //

    NVIC_InitStruct.NVIC_IRQChannel = ADC_COMP_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 0;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    ADC_ClearITPendingBit(ADC1, ADC_IT_EOC);
    ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);

    ADC_ANY_Cmd(ADC1, DISABLE); //Enable and use ANYChan to control ADC sample

    ADC_ANY_NUM_Config(ADC1, 3); //set Single(one) Channel as Analog iuput

    ADC_ANY_CH_Config(ADC1, 0, ADC_Channel_0); //assign ADC channel 1 to RANK 0;  PB1  Channel0
    ADC_ANY_CH_Config(ADC1, 1, ADC_Channel_1); //assign ADC channel 1 to RANK 1;  PB0  Channel1
    ADC_ANY_CH_Config(ADC1, 2, ADC_Channel_6); //assign ADC channel 1 to RANK 2;  PA15 Channel6

    ADC_ANY_Cmd(ADC1, ENABLE); //Enable and use ANYChan to control ADC sample

    ADC_Cmd(ADC1, ENABLE); //Enable AD conversion();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  void ADC1_IRQHandler(void)
/// @note
/// @param
/// @retval None.
////////////////////////////////////////////////////////////////////////////////

void ADC1_IRQHandler(void)
{
    if (RESET != ADC_GetITStatus(ADC1, ADC_IT_EOC))
    {
			  GPIOA-> ODR |= 0x0800; //PA11
			
        ADC_ClearITPendingBit(ADC1, ADC_IT_EOC);

        ADC_Buff[0] = ADC1->ADDR0;
        ADC_Buff[1] = ADC1->ADDR1;
        ADC_Buff[2] = ADC1->ADDR6;
			
			  GPIOA-> ODR &= ~0x0800; //PA11
			
			  
    }
}

/// @}

/// @}

/// @}
