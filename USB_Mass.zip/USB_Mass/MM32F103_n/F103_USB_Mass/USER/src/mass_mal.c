/******************** (C) COPYRIGHT 2009 MM32 ********************
* File Name          : mass_mal.c
* Author             : MCD Application Team
* Version            : V3.0.1
* Date               : 04/27/2009
* Description        : Medium Access Layer interface
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MM32 SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/

#include "platform_config.h"
#include "mass_mal.h"
#include "hal_conf.h"

#include "mass_mal.h"
#include "uart.h"
#include "mm32flash.h"


#define     FLASH_START_ADDR        0x08008000    // Flash start address 
#define     FLASH_SIZE              0x8000  	  // 32K ?U? 
#define     FLASH_PAGE_SIZE         0x400         // 1k Bytes per page,
#define     FLASH_WAIT_TIMEOUT      100000

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint32_t Mass_Memory_Size[2];
uint32_t Mass_Block_Size[2];
uint32_t Mass_Block_Count[2];
__IO uint32_t Status = 0;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : MAL_Init
* Description    : ???MM32?????
* Input          : lun
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t MAL_Init(uint8_t lun)
{
  u16 status = MAL_OK;

  switch (lun)
  {
    case 0:  
		FLASH_Unlock(); 
             break;
    default:
             return MAL_FAIL;
  }
  return status;
}
/*******************************************************************************
* Function Name  : MAL_Write
* Description    : ???
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t MAL_Write(uint8_t lun, uint32_t Memory_Offset, uint16_t *Writebuff, uint16_t Transfer_Length)
{
//  uint16_t i;
  switch (lun)
  {
    case 0:  
        
    MM32FLASH_Write(FLASH_START_ADDR + Memory_Offset,Writebuff,Transfer_Length/2);				
//		for(i=0;i<Transfer_Length;i+=FLASH_PAGE_SIZE)
//		{
//			if(FLASH_WaitForLastOperation(FLASH_WAIT_TIMEOUT)!=FLASH_TIMEOUT)
//			{
//				FLASH_ClearFlag(FLASH_FLAG_EOP|FLASH_FLAG_PGERR|FLASH_FLAG_WRPRTERR);
//			}
//			FLASH_ErasePage(FLASH_START_ADDR + Memory_Offset + i); 			
//		}
//		for(i=0;i<Transfer_Length;i+=4)
//		{
//			if(FLASH_WaitForLastOperation(FLASH_WAIT_TIMEOUT)!=FLASH_TIMEOUT)
//			{
//				FLASH_ClearFlag(FLASH_FLAG_EOP|FLASH_FLAG_PGERR|

//FLASH_FLAG_WRPRTERR);
//			}
//			FLASH_ProgramWord(FLASH_START_ADDR + Memory_Offset + i , Writebuff[i>>2]);
//		}
//    printf("MAL_Write OK,");
    return MAL_OK;		

    default:
//		printf("MAL_Write fail,");
      return MAL_FAIL;
  }
  return MAL_OK;
}

/*******************************************************************************
* Function Name  : MAL_Read
* Description    : ????
* Input          : None
* Output         : None
* Return         : Buffer pointer
*******************************************************************************/
uint16_t MAL_Read(uint8_t lun, uint32_t Memory_Offset, u16 *Readbuff, uint16_t Transfer_Length)
{
//  uint32_t i;
  switch (lun)
  {
    case 0:
       MM32FLASH_Read(FLASH_START_ADDR+Memory_Offset,(u16 *)Readbuff, Transfer_Length/2);

//		for(i=0;i<Transfer_Length;i+=4)
//		{
//			Readbuff[i>>2] = ((vu32*)(FLASH_START_ADDR + Memory_Offset))[i>>2];
//		}
//		printf("MAL_Read ok,");
		return MAL_OK;	

    default:
	//		printf("MAL_Read faild,");
      return MAL_FAIL;
  }
  return MAL_OK;
}

/*******************************************************************************
* Function Name  : MAL_GetStatus
* Description    : ????
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t MAL_GetStatus (uint8_t lun)
{
   	if (lun == 0)
   	{
  		Mass_Block_Count[0] = FLASH_SIZE/FLASH_PAGE_SIZE; 
		Mass_Block_Size[0] = FLASH_PAGE_SIZE;                    
		Mass_Memory_Size[0] = FLASH_SIZE;
	//	LED2_ON();
		return MAL_OK;
	}
  //	LED2_OFF();
 
  	return MAL_FAIL;
}





/******************* (C) COPYRIGHT 2009 MM32 *****END OF FILE****/
