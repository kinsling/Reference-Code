/******************** (C) COPYRIGHT 2009 MM32 ********************
* File Name          : platform_config.h
* Author             : MCD Application Team
* Version            : V3.0.1
* Date               : 04/27/2009
* Description        : Evaluation board specific configuration file.
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MM32 SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __PLATFORM_CONFIG_H
#define __PLATFORM_CONFIG_H

/* Includes ------------------------------------------------------------------*/
#include "hal_conf.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Uncomment the line corresponding to the MM32 evaluation board
   used to run the example */
#if !defined (USE_MM3210B_EVAL) &&  !defined (USE_MM3210E_EVAL)
 //#define USE_MM3210B_EVAL
 #define USE_MM3210E_EVAL
#endif
/* Define the MM32F10x hardware depending on the used evaluation board */
#ifdef USE_MM3210B_EVAL

  #define USB_DISCONNECT                    GPIOD  
  #define USB_DISCONNECT_PIN                GPIO_Pin_9
  #define RCC_AHBPeriph_GPIO_DISCONNECT    RCC_AHBPeriph_GPIOD

  #define USB_LED_PORT                      GPIOC
  #define RCC_AHBPeriph_GPIO_LED           RCC_AHBPeriph_GPIOC
#else /* USE_MM3210E_EVAL */

  #define USB_DISCONNECT                    GPIOB  
  #define USB_DISCONNECT_PIN                GPIO_Pin_14
  #define RCC_AHBPeriph_GPIO_DISCONNECT    RCC_AHBPeriph_GPIOB

  #define USB_LED_PORT                      GPIOB
  #define RCC_AHBPeriph_GPIO_LED           RCC_AHBPeriph_GPIOB

#endif /* USE_MM3210B_EVAL */

/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

#endif /* __PLATFORM_CONFIG_H */

/******************* (C) COPYRIGHT 2009 MM32 *****END OF FILE****/
