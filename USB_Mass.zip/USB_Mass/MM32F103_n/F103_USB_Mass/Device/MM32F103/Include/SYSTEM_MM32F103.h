#ifndef __SYSTEM_MM32F103_H__
#define __SYSTEM_MM32F103_H__


extern uint32_t SystemCoreClock;
void SystemInit (void);

#endif
