#ifndef __TIM3_H_
#define __TIM3_H_
#include "HAL_conf.h"


void Tim3_UPCount_test(u16 Prescaler,u16 Period);

extern uint8_t Flag_Receive;
extern uint8_t Flag_once;

#endif
