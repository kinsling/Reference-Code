#ifndef __UART_NVIC_H
#define __UART_NVIC_H
#include "HAL_conf.h"
#include  "stdio.h"
#include "dtype.h"


void UART2_Send_BUFF( uint8_t *Str,uint8_t len);

#endif


