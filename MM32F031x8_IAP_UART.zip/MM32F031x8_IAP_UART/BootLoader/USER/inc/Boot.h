#ifndef   __BOOT_H_
#define    __BOOT_H_

#include "HAL_device.h"


uint16_t DFU_read_state(void);

void APP_Update(void);


#endif



/***************************end of file****************************************************/



