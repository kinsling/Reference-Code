#ifndef __SYSTEM_MM32L3xx_H__
#define __SYSTEM_MM32L3xx_H__
extern uint32_t SystemCoreClock;
void SystemInit (void);

#endif
