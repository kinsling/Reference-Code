#include "HAL_device.h"
#include "dac.h"
#include "string.h"
#include "math.h"


#define PI  3.141592654

float Voltage_margin;

uint16_t DAC_Period;        // 16位计数器重载值
uint8_t  DAC_Prescaler;      // 时钟预分频 


u16 dma_data[256];
float voltage = 1.6;
unsigned short Voltage_AD;

/*****************************************************************************************
//Voltage_margin        :输出电压的峰值(0~1.6)
******************************************************************************************/

u16 SineWave_Value[256];       //输出buff

/********正弦波输出表***********/
void SineWave_Data( u16 cycle ,u16 *D)
{
    u16 i;
    for( i=0;i<cycle;i++)
    {
        D[i]=(u16)((Voltage_margin*sin(( 1.0*i/(cycle-1))*2*PI)+Voltage_margin)*4095/3.3);
    }
}

float f;
/********锯齿波输出表***********/

void Sawtooth_data(void)   
{
	u16 i;
    f= 0.8;
	Voltage_AD = (4095*voltage)/3.3;
	for(i=0;i<256;i++)
	{
			dma_data[i]= (u16)((i*((1.0/f)/256))*((float)Voltage_AD/(1.0/f)));

	}
}

/* Private functions ---------------------------------------------------------*/


void DAC_GPIO_Configuration(void)
{
			GPIO_InitTypeDef GPIO_InitStructure;
			
			/* Once the DAC channel is enabled, the corresponding GPIO pin is automatically 
			connected to the DAC converter. In order to avoid parasitic consumption, 
			the GPIO pin should be configured in analog */
			GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4;
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
			GPIO_Init(GPIOA, &GPIO_InitStructure);
    
			GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_5;
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
			GPIO_Init(GPIOA, &GPIO_InitStructure);
    
}

void TIM_Initial(void)  //TIM 触发DMA更新一次数据   96Mhz HSI
{
		
			TIM_TimeBaseInitTypeDef    TIM_TimeBaseStructure;
		
			/* TIM3 Configuration */
			TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
			TIM_TimeBaseStructure.TIM_Period = DAC_Period-1;          
			TIM_TimeBaseStructure.TIM_Prescaler = DAC_Prescaler-1;       
			TIM_TimeBaseStructure.TIM_ClockDivision = 0x0;    
			TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 

    
			TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
    
			TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);    
		
			/* TIM3 TRGO selection */
			TIM_SelectOutputTrigger(TIM3, TIM_TRGOSource_Update);

			/* TIM2 TRGO selection */
			TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_Update);
	
	
		
}




/* Private functions ---------------------------------------------------------*/

void DAC_Channel1_DMA_Config(void)
{
    DMA_InitTypeDef  DMA_InitStructure;
    
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    
    DMA_DeInit(DMA1_Channel6);                                         //tim1_ch1
    DMA_InitStructure.DMA_PeripheralBaseAddr =(u32)(&(DAC->DHR12R1));
    DMA_InitStructure.DMA_MemoryBaseAddr = (u32)(&SineWave_Value);  //
	
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 256;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    
    DMA_Init(DMA1_Channel6, &DMA_InitStructure);
    
    DMA_Cmd(DMA1_Channel6, ENABLE);
    
    DAC_DMACmd(DAC_Channel_1,ENABLE);
		
}


void DAC_Channel2_DMA_Config(void)
{
    DMA_InitTypeDef  DMA_InitStructure;
    
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    
    DMA_DeInit(DMA1_Channel7);                                         //tim1_ch1
    DMA_InitStructure.DMA_PeripheralBaseAddr =(u32)(&(DAC->DHR12R2));
    DMA_InitStructure.DMA_MemoryBaseAddr = (u32)(&dma_data);  //
	
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 256;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    
    DMA_Init(DMA1_Channel7, &DMA_InitStructure);
    
    DMA_Cmd(DMA1_Channel7, ENABLE);
    
    DAC_DMACmd(DAC_Channel_2,ENABLE);
		
}



void DAC_RCC_config(void)
{
	
		/* Enable peripheral clocks ------------------------------------------------*/
		/* GPIOA Periph clock enable */
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
		/* DAC Periph clock enable */
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
		/* TIM2 Periph clock enable */
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

	
	
}




void DAC_Config(void)
{
	
        DAC_InitTypeDef            DAC_InitStructure;

        Voltage_margin=1.5;    // 配置电压幅度

        DAC_Period = 18;	      //修改频率   
        DAC_Prescaler = 2;

        SineWave_Data(256,SineWave_Value);     //生成输出正弦波的波形表

        Sawtooth_data();  //锯齿波生成

        DAC_RCC_config();

        DAC_GPIO_Configuration();

        TIM_Initial();

        /* DAC channel1 Configuration */
        DAC_InitStructure.DAC_Trigger = DAC_Trigger_T3_TRGO;//DAC_Trigger_None;  //使用触发功能
        DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;    //不使用波形发生器
        DAC_InitStructure.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;  //屏蔽幅值设置
        DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;  ////DAC1输出缓存打开BOFF1=0
        DAC_Init(DAC_Channel_1, &DAC_InitStructure);

        /* DAC channel2 Configuration */
        DAC_InitStructure.DAC_Trigger = DAC_Trigger_T2_TRGO;//DAC_Trigger_None;  //使用触发功能
        DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;    //不使用波形发生器
        DAC_InitStructure.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;  //屏蔽幅值设置
        DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;  ////DAC1输出缓存打开BOFF1=0
        DAC_Init(DAC_Channel_2, &DAC_InitStructure);        


        /* Enable DAC Channel1: Once the DAC channel1 is enabled, PA.04 is 
        automatically connected to the DAC converter. */
        DAC_Cmd(DAC_Channel_1, ENABLE);
        DAC_Cmd(DAC_Channel_2, ENABLE);         


        DAC_Channel1_DMA_Config();
        DAC_Channel2_DMA_Config();

        /* TIM3 enable counter */
        TIM_Cmd(TIM3, ENABLE);
        /* TIM2 enable counter */
        TIM_Cmd(TIM2, ENABLE);	
}


/***********************************************end of file**************************************************************/






