
#ifndef __DAC_H
#define __DAC_H

#include "HAL_device.h"

void DAC_Config(void);

#endif



/************************************end of file******************************************************/



