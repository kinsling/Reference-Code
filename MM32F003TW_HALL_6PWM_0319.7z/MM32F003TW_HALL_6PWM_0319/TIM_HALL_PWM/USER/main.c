
#include "HAL_device.h"
#include "stdio.h"
#include "HAL_conf.h"
#include "pwm.h" 
#include "led.h"
#include "delay.h"
#include "tim2.h"
#include "adc.h"
#include "uart.h"	

/*******************************************************************************
* @name   : main
* @brief  : TIM PWM output
* @param  : None
* @retval : void
*******************************************************************************/
extern uint16_t Temp_data1,Temp_data2;

/*
GPIO/OSC***********************************************************

PD0
PD1

ADC***********************************************************

PB3  ADC  Channel10
PB7  ADC  Channel12   // UART2_TX  //DEBUG

TIM1***********************************************************

PA4 TIM1_BKIN

PB14 TIM1_CH1
PB13 TIM1_CH1N
PB1  TIM1_CH2
PB0  TIM1_CH2N
PA6  TIM1_CH3
PA5  TIM1_CH3N 

TIM2***********************************************************

PB6  TIM2_CH1
PB4  TIM2_CH2
PA0  TIM2_CH3
*/

u16 TempADCValue1,TempADCValue2,VerfADCValue;

int main(void)
{   

	  delay_init();	  //SysTick initial 
	
	  GPIO_Config();  //GPIO config
		  
	  ADC_Initial();
	
    uart_initwBaudRate(230400);  //Initial UART 115200 PB7 TX
	
	  //TIM_PWM_Init(1500,0,10);	  //Config TIM1  16Khz
		
		//Time2 Initial
		TIM2_Init(TIM2_PRIOD, TIM2_PSC_LOAD); 			//HALL capture
	
//    TIM_SetCompare1(TIM1,1000);	 //TIM1_CH1
//	  TIM_SetCompare2(TIM1,600);	 //TIM1_CH2
//	  TIM_SetCompare3(TIM1,300);	 //TIM1_CH3
    
    while(1)
		{
			
//			TempADCValue1 = Get_Adc_Average(ADC_Channel_10,16);          //PB3 Channel 10
////			TempADCValue2 = Get_Adc_Average(ADC_Channel_12,16);          //PB7 Channel 12
//			VerfADCValue  = Get_Adc_Average(ADC_Channel_Vrefint,16);     //���ڲ��ο���ѹ1.2V ��5%���ȣ�	
			
			if(CollectFlag)
			{	
         CollectFlag = 0;
         printf("%d %d",Temp_data1,Temp_data2);				
				 //printf("period=%d position=%d\r\n", period,position);	     //1 3 2 6 4 5				
		  }
			
			
    }
		
		
}


