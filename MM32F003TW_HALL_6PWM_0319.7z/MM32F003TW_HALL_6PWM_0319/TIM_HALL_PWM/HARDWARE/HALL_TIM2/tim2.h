#ifndef __TIM2_H_
#define __TIM2_H_

//#include "HAL_device.h"

#include "HAL_conf.h"

extern u32 period ;
extern u32 duty ;
extern u8 CollectFlag;
extern uint8_t position;

void TIM2_PWMINPUT_INIT(u16 arr,u16 psc);

extern uint16_t ucTim2Flag;


#define FCY  ((u32)48000000)                         //系统时钟
#define FPWM  ((u16)16000)                           //PWM频率
#define PWM_PRIOD_LOAD (u16)(FCY/FPWM/2 - 1)         //PWM周期装载值
#define DEADTIME ((float) 0.000001)                  //定义死区时间
#define DEADTIME_LOAD ((u16)(DEADTIME*FCY))	         //死区装载值

#define TIM2_TCY      1                           		//定时器2时基单位us  
#define TIM2_PSC_LOAD (u16)(FCY/1000000*TIM2_TCY-1)   //定时器2装载值
#define TIM2_PRIOD    99999                          	//定时器2周期值


extern void TIM2_Init(u32 arr, u16 psc);

#endif
