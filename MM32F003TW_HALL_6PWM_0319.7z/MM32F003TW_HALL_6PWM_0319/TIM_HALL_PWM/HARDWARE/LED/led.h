#ifndef __LED_H
#define __LED_H	 
#include "HAL_conf.h"

//////////////////////////////////////////////////////////////////////////////////	 
//������
//LED��������	   
////////////////////////////////////////////////////////////////////////////////// 

#define LED0_ON()  GPIO_ResetBits(GPIOD,GPIO_Pin_0)	// PD0
#define LED0_OFF()  GPIO_SetBits(GPIOD,GPIO_Pin_0)	// PD0
#define LED0_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOD,GPIO_Pin_0))?(GPIO_ResetBits(GPIOD,GPIO_Pin_0)):(GPIO_SetBits(GPIOD,GPIO_Pin_0))	// PD0

#define LED1_ON()  GPIO_ResetBits(GPIOD,GPIO_Pin_1)	// PD1
#define LED1_OFF()  GPIO_SetBits(GPIOD,GPIO_Pin_1)	// PD1
#define LED1_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOD,GPIO_Pin_1))?(GPIO_ResetBits(GPIOD,GPIO_Pin_1)):(GPIO_SetBits(GPIOD,GPIO_Pin_1))	// PD1


void GPIO_Config(void);//��ʼ��

		 				    
#endif
