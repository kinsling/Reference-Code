#include "adc.h"


/*******************************************************************************
* @name   : void ADC_Initial(void)
* @brief  : 
* @param  : None
* @retval : void
*******************************************************************************/


void ADC_Initial(void)
{
			
	  ADC_InitTypeDef      ADC_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
	
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE); 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_3/*|GPIO_Pin_7*/;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    /*��PB3 PB7����Ϊģ������*/
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	  ADC_DeInit(ADC1);
	  ADC_StructInit(&ADC_InitStructure);
	
    /* Initialize the ADC_PRESCARE values */
    ADC_InitStructure.ADC_PRESCARE = ADC_PCLK2_PRESCARE_4; //48M/4=12M
    /* Initialize the ADC_Mode member */
    ADC_InitStructure.ADC_Mode = ADC_Mode_Single;
    /* Initialize the ADC_DataAlign member */
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    /* Initialize the ADC_ExternalTrigConv member */
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
    ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
    ADC_Init(ADC1, &ADC_InitStructure);
    
    /*��������ͨ��*/
    ADC_RegularChannelConfig(ADC1, DISABLE_ALL_CHANNEL , 0, 0); 
    /*ʹ��ѡ��ͨ��,�����������*/
    ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 0, ADC_SampleTime_28_5Cycles); 
//    ADC_RegularChannelConfig(ADC1, ADC_Channel_12, 0, ADC_SampleTime_28_5Cycles); 
    ADC_RegularChannelConfig(ADC1, ADC_Channel_Vrefint, 0, ADC_SampleTime_28_5Cycles);
		
    ADC_TempSensorCmd(ENABLE);
    ADC_VrefintCmd(ENABLE);
		
    ADC_Cmd(ADC1, ENABLE); 
	
	
		
}


/*******************************************************************************
* @name   : u16 ADC1_SingleChannel_Get(uint8_t ADC_Channel_x)
* @brief  : 
* @param  : None
* @retval : void
*******************************************************************************/
u16 ADC1_SingleChannel_Get(uint8_t ADC_Channel_x)
{ 
    u16 puiADData;
    /*ADCR�Ĵ�����ADSTλʹ�ܣ���������ת��*/
			if(ADC_Channel_x == ADC_Channel_10)
			{
				ADC1->ADCHS |= 0x00000400;
			}
			else if(ADC_Channel_x == ADC_Channel_12)
			{
				ADC1->ADCHS |= 0x00001000;			
			}
			else if(ADC_Channel_x == ADC_Channel_Vrefint)
			{
				ADC1->ADCHS |= 0x00008000;			
			}
			
    ADC_SoftwareStartConvCmd(ADC1, ENABLE); 
    while(ADC_GetFlagStatus(ADC1,ADC_FLAG_EOC)==0);
    ADC_ClearFlag(ADC1, ADC_FLAG_EOC);
    puiADData=ADC_GetConversionValue(ADC1);
	  ADC1->ADCHS &= (uint32_t)0xFFFF0000;
    return puiADData;
}

/*******************************************************************************
* @name   : Get_Adc_Average(uint8_t ADC_Channel_x,uint8_t times)
* @brief  : 
* @param  : None
* @retval : void
*******************************************************************************/

u16 Get_Adc_Average(uint8_t ADC_Channel_x,uint8_t times)
{
    u32 temp_val=0;
    u8 t;
    u8 delay;
    for(t=0;t<times;t++)
    {
        temp_val+=ADC1_SingleChannel_Get(ADC_Channel_x);
        for(delay=0;delay<100;delay++);
    }
		
    return temp_val/times;
}

/*******************************************************************************
* @name   : void ADC_COMP_IRQHandler()
* @brief  : 
* @param  : None
* @retval : void
*******************************************************************************/
void ADC_COMP_IRQHandler()
{		
        if (ADC_GetITStatus(ADC1, ADC_IT_EOC) != RESET)//ADC1 ת�����
        {   
					ADC_ClearITPendingBit(ADC1, ADC_IT_EOC );  //����жϱ�־λ					
        }	
		
}




