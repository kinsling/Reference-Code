#ifndef _ADC_H_
#define _ADC_H_

#include "HAL_conf.h"

void ADC_Initial(void);
u16 Get_Adc_Average(uint8_t ADC_Channel_x,uint8_t times);

#endif

