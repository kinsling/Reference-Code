
// DFUToolsDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DFUTools.h"
#include "DFUToolsDlg.h"
#include "afxdialogex.h"
#include <math.h>
#include "HIDCmd.h"


//#include "Driver/util.h"

#include "setupapi.h"		// Must link in setupapi.lib
#include "hidsdi.h"			// Must link in hid.lib


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CString OpenFilePath;


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

CString strDeviceID[3];

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CDFUToolsDlg �Ի���




CDFUToolsDlg::CDFUToolsDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDFUToolsDlg::IDD, pParent)
	, m_Info(_T(""))
	, msg_Verinfo(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDFUToolsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_Info);
	DDX_Text(pDX, IDC_STATIC_DRVVER, msg_Verinfo);
}

BEGIN_MESSAGE_MAP(CDFUToolsDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_DOWNLOAD, &CDFUToolsDlg::OnBnClickedDownload)
	ON_BN_CLICKED(IDC_LOAD, &CDFUToolsDlg::OnBnClickedLoad)
	ON_EN_CHANGE(IDC_EDIT_PATH, &CDFUToolsDlg::OnEnChangeEditPath)
	ON_BN_CLICKED(IDC_TEST, &CDFUToolsDlg::OnBnClickedTest)
	ON_BN_CLICKED(IDC_READ_FW_VER, &CDFUToolsDlg::OnBnClickedReadFwVer)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_PROGRESS1, &CDFUToolsDlg::OnNMCustomdrawProgress1)
	//ON_EN_CHANGE(IDC_EDIT1, &CDFUToolsDlg::OnEnChangeEdit1)
	ON_STN_CLICKED(IDC_STATIC_DRVVER, &CDFUToolsDlg::OnStnClickedStaticDrvver)
	ON_BN_CLICKED(IDC_CLEARDIS, &CDFUToolsDlg::OnBnClickedCleardis)
	ON_BN_CLICKED(IDC_OPENVCOM, &CDFUToolsDlg::OnBnClickedOpenvcom)
END_MESSAGE_MAP()


// CDFUToolsDlg ��Ϣ��������

BOOL CDFUToolsDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������

	OpenDevice();
	dwFileLen = 0;

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CDFUToolsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CDFUToolsDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
   //add
//	GetDlgItem(IDC_EDIT_PATH)->SetWindowTextW(OpenFilePath); 
//	GetDlgItem(IDC_EDIT_PATH)->SetWindowTextW(SaveFilePath); 

}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CDFUToolsDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CDFUToolsDlg::OnBnClickedDownload()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnBootfw();


}

void CDFUToolsDlg::OnBnClickedLoad()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������


	BOOL ulRet;
	CFile file;
	PUCHAR pucFileBuf; //,backupFileBuf
	unsigned char* ucReadBuf = NULL;
	CString strCodeFileEn;
//	unsigned char WriteBuf[256*1024] = {0};  //256K

	CFileDialog dlg(TRUE);///TRUEΪOPEN�Ի���FALSEΪSAVE AS�Ի���  
	if(dlg.DoModal()==IDOK)  
		OpenFilePath=dlg.GetPathName();  
	GetDlgItem(IDC_EDIT_PATH)->SetWindowTextW(OpenFilePath); 

	GetDlgItemText(IDC_EDIT_PATH, OpenFilePath);

	if (OpenFilePath == "")
	{
		DisInformation(_T("Please select a file address!"),1);
		return;
	}

	if(file.Open(OpenFilePath, CFile::modeRead | CFile::typeBinary) == FALSE)
	{
		DisInformation(_T("File open failed!"),1);
		return;
	}
	dwFileLen = (DWORD)file.GetLength();

	if (dwFileLen > MAX_FILE_LEN)
	{
		DisInformation(_T("File cannot be larger than 256k"),1);
		return;
	}
	pucFileBuf = (PUCHAR)malloc(dwFileLen);
	memset(WriteBuf, 0x00, 256*1024);
	memset(pucFileBuf, 0x00, dwFileLen);
	file.Read(pucFileBuf, dwFileLen);
	memcpy(WriteBuf,pucFileBuf,dwFileLen);

	file.Close();

	//DWORD ulLen = dwFileLen;
	//if (0!=ulLen%512)
	//{			
	//	ulLen = ulLen + 512 - ulLen%512;
	//}
	//backupFileBuf = (PUCHAR)malloc(dwFileLen);
	//memset(backupFileBuf, 0x00, dwFileLen);
	//memcpy(backupFileBuf,pucFileBuf,dwFileLen);
	//ucReadBuf = (unsigned char*)malloc(ulLen);
	//memset(ucReadBuf,0,ulLen);

	free(pucFileBuf);  //�ͷ�

	DisInformation(_T("Read file successfully!"),1);


}



void CDFUToolsDlg::OnEnChangeEditPath()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialogEx::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
}


void CDFUToolsDlg::OnBnClickedTest()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������


}


void CDFUToolsDlg::OnBnClickedReadFwVer()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	m_Version = GetFTVersion();
	if(	m_Version != 0)
	CheckUpdate(m_Version);
}





///////////////////////////////////////////////////////////



CString CDFUToolsDlg::ReadIniOneKey(UINT unSection,UINT unKey,CString iniFilename)
{ 
	CString Section,Key,KeyValue;
	Section.Format(_T("%d"),unSection);
	Key.Format(_T("%d"),unKey);
	::GetPrivateProfileString(Section,Key,_T("1"),KeyValue.GetBuffer(20),20,iniFilename);

	return KeyValue;
}


BOOL CDFUToolsDlg::ReadHEX(CString strFileName,BYTE *pData,int size)
{
	CString    filepath;  
	CStdioFile wfile; 
	if (!wfile.Open(strFileName,CFile::modeRead|CFile::typeBinary)) 
	{  
		AfxMessageBox(L"�޷����ļ�"); 
		return 0;  
	}  

	ULONGLONG len=wfile.GetLength(); 
	//byte *pByte=NULL; 
	BOOL Unicodeflg = TRUE;
	if (len>0)  
	{  
		//pByte=new byte[len]; 
		//memset(pByte,0,len*sizeof(byte));  
		WORD sign; 
		wfile.SeekToBegin(); 
		wfile.Read(&sign,2); 
		if (sign!=0xfeff)  
		{
			wfile.Close(); //����UNicode����
			//CStdioFile inFile;
			if(!wfile.Open(strFileName,CFile::modeRead))
			{
				MessageBox(_T("Դ�ļ����ܴ�"));
				return 0;
			}
			//ReadHEX_MulByte(strFileName,pData,size);
			Unicodeflg = FALSE;
		}
		else
		{ // Unicode
			//��ȡ�ļ�
			Unicodeflg = 1;
		}
		CString str;
		CString strline;
		BYTE length ,style;//,data,chacksum
		WORD adr,Exadr = 0,Exladr = 0;
		WORD adrbuf = 0;
		while (wfile.ReadString(str))    // ��ʱ����õ�str�ַ���  ���лس���\r  ���ǲ������з�\n  
		{  
			// ȥ�� �س��� \r  ��ò����س����з��Ĵ�����ַ�������  
			if(Unicodeflg)			
				str=str.Left(str.GetLength()-1);  
			strline= str;  

			length = Toint(strline.Mid(1,2),16);
			adr = Toint(strline.Mid(3,4),16);
			style = Toint(strline.Mid(7,2),16);

			if(style == 1)//�ļ�����
				break;
			int j = 0;
			switch(style)
			{
			case 0:
				{
					long madr = Exladr*0x10000+(Exadr<<1)+adr;
					if(madr+length-1<size)
					{
						for(int i = 0;i<length;i++)
						{
							CString Data = strline.Mid(9+j,2);
							*(pData+madr+i) = Toint(Data,16);
							j += 2;
						}
						adrbuf = madr+length;
					}
					else if(((madr+length-1)>size)&&(madr+length-1<0x4000))
					{
						MessageBox(_T("File size unmatch!"));
						wfile.Close();
						return 0;
					}
					else if(madr+length-1>0x4030)//HEX�ļ�
					{
						MessageBox(_T("File size unmatch!"));
						wfile.Close();
						return 0;
					}
				}
				break;
			case 2:
				Exadr = Toint(strline.Mid(9,2*length),16);
				break;
			case 4:
				Exladr = Toint(strline.Mid(9,2*length),16);
				break;
			default:
				break;
			}  
		}
		int nAdr = Exladr*0x10000+(Exadr<<1)+adrbuf;
		for(int n = nAdr;n <m_nFlashSize*2-2;n+= 2)//������ַ������ַ��0xFF
		{
			//m_BFlash[n] = 0xFF;
			//m_BFlash[n+1] = 0x3F;
		}

	}
	else
	{
		AfxMessageBox(L"�ļ�����Ϊ0 "); 
		wfile.Close(); 
		return 0;  
	}
	wfile.Close(); 
	return 1;

	/*	*/
}


BOOL CDFUToolsDlg::ReadBin(CString strFileName,BYTE *pData,int size)
{
	CStdioFile inFile;
	if(!inFile.Open(strFileName,CFile::modeRead|CFile::typeBinary))
	{
		MessageBox(_T("File cannot be opened!"));
		return 0;
	}
	//------------�ļ���ȡ---------------------
	inFile.Read(pData,size);//��ȡFlash����
	//-----------------------------------------
	inFile.Close();
	return 1;

}


//Style = 1 Flash�ļ�ת��Ϊ��ˣ�
BOOL CDFUToolsDlg::ReadFiletoBuffer(CString strFileName,BYTE *pData,int size,int Style)
{
	CString strNameTemp = strFileName;
	strNameTemp.MakeLower();
	if(strNameTemp.Find(_T(".hex"),0) != -1)
	{
		if(!ReadHEX(strFileName,pData,size))
			return 0;
	}
	else if(strNameTemp.Find(_T(".bin"),0) != -1)
	{
		if(!ReadBin(strFileName,pData,size))
			return 0;
	}
	if(Style)
		CoverToDaDuan(pData,size);

	return 1;
}





int CDFUToolsDlg::Toint(CString Imm,int radix)
{
	if(Imm.IsEmpty())
		return -1;
	Imm.MakeUpper();
	double value= 0;
	switch (radix)
	{
	case 10:
		for(int i=Imm.GetLength()-1;i>=0;i--)
		{
			WCHAR ch = Imm.GetAt(i);
			int k=0;
			switch(ch)
			{
			case '0':  k=0;  break;
			case '1':  k=1;  break;
			case '2':  k=2;  break;
			case '3':  k=3;  break;
			case '4':  k=4;  break;
			case '5':  k=5;  break;
			case '6':  k=6;  break;
			case '7':  k=7;  break;
			case '8':  k=8;  break;
			case '9':  k=9;  break;
			default:
				break;
			}
			value += k*pow(10.0,Imm.GetLength()-1-i);
		}
		break;
	case 16:
		for(int i=Imm.GetLength()-1;i>=0;i--)
		{
			WCHAR ch = Imm.GetAt(i);
			int k=0;
			switch(ch)
			{
			case '0':  k=0;  break;
			case '1':  k=1;  break;
			case '2':  k=2;  break;
			case '3':  k=3;  break;
			case '4':  k=4;  break;
			case '5':  k=5;  break;
			case '6':  k=6;  break;
			case '7':  k=7;  break;
			case '8':  k=8;  break;
			case '9':  k=9;  break;
			case 'A':  k=10; break;
			case 'B':  k=11; break;
			case 'C':  k=12; break;
			case 'D':  k=13; break;
			case 'E':  k=14; break;
			case 'F':  k=15; break;
			default:
				break;
			}
			value += k*pow(16.0,Imm.GetLength()-1-i);
		}
		break;
	case 2:
		for(int i=Imm.GetLength()-1;i>=0;i--)
		{
			WCHAR ch = Imm.GetAt(i);
			int k=0;
			switch(ch)
			{
			case '0':  k=0;  break;
			case '1':  k=1;  break;
			default:
				break;
			}
			value += k*pow(2.0,Imm.GetLength()-1-i);
		}
		break;
	}
	return (int)value;
}

unsigned short CDFUToolsDlg::CheckSum(BYTE *addr, BYTE count)
{
	register int sum = 0;

	while( count > 0 ) 
	{
		sum =sum+*addr;
		addr++;
		count --;
	}

	while (sum>>16)//���͵ĸ�16λ��Ϊ0���Ѹ�16λ��ΪУ��͵�һ������ͣ�
		sum = (sum & 0xffff) + (sum >> 16);

	return (short)~sum;
}


//���д���������
BOOL CDFUToolsDlg::SendCMDandData(BYTE *pData,int packlth)
{	
	BYTE CMDDATA[0x40]={0};
	unsigned long length;
	BOOL bRet;
	BYTE j = 0;	
	WORD ckSum = 0;

	for(j=0;j<packlth;j++)
	{
		CMDDATA[j] = *pData;
		pData++;
	}
	ckSum = CheckSum(CMDDATA,CMDDATA[1]-2);
	CMDDATA[CMDDATA[1]-1] = ckSum & 0x00FF;
	CMDDATA[CMDDATA[1]-2] = (ckSum>>8) & 0x00FF;

		bRet = m_Hid.WriteFileCmd(CMDDATA,0x40 , &length, USB_TIME_OUT);
		if(!bRet)
			return FALSE;

	return TRUE;
}


//���м�����
BOOL CDFUToolsDlg::GetSimpleCMD(BYTE *pCMD,BYTE Size)
{
	BYTE CMDDATA[0x40]={0};
	unsigned long length;
	BOOL bRet;	
	//------------------------------------------------------

	bRet = m_Hid.ReadFileCmd(CMDDATA,0x40,&length,USB_TIME_OUT);
	if(bRet)
	{
			for(int i = 0;i<Size;i++)
			{
				*pCMD = CMDDATA[i];
				pCMD++;
			}
	}

	return bRet;	
}


BOOL  CDFUToolsDlg::OpenDevice()
{	
	DisInformation(_T(""),0);//����

	if(!m_Hid.OpenDevice(VID,PID,SVN))
	{
		//DisInformation(_T("***************************************************************"),1);
		DisInformation(_T("USB Connect Fail!"),1);
		//OpenHidflg = TRUE;
		return FALSE;
	}
	//DisInformation(_T("***************************************************************"),1);
	//DisInformation(_T("USB Connect OK!"),1);
	//GetFTVersion();
	return TRUE;
}

void  CDFUToolsDlg::CloseDevice()
{	
	m_Hid.CloseDevice();
	//OpenHidflg = FALSE;
}

void CDFUToolsDlg::DisInformation(CString strMessage,int type)
{

	switch(type)
	{
	case 0://����
		m_EditInformation.Empty();

    	m_Info = m_EditInformation;

		break;

	case 1://������Ϣ
  
		m_EditInformation += strMessage +_T("\r\n");
		m_Info = m_EditInformation;

		break;
	}
	UpdateData(FALSE);

	CEdit* pedit = (CEdit*)GetDlgItem(IDC_EDIT1); 
	pedit->LineScroll(pedit->GetLineCount());

    GetDlgItem(IDC_EDIT1)->ShowScrollBar(SB_VERT, TRUE);  //��Ϣ�����Զ��ӹ�����

}


DWORD  CDFUToolsDlg::GetFTVersion()//��ȡ�̼��汾��
{
	BOOL ret;
	BYTE gCMD[10];
	DWORD Version = 0;
	CString Dis_ver;

	int progressstep = 0;  //test
    ((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(progressstep);

	if(!m_Hid.OpenDevice(VID,PID,SVN))
	{
		DisInformation(_T("USB Connect Fail!"),1);
		Version =0;
		return 0;
	}

	gCMD[0] = 0x00;  //command
	gCMD[1] = 10;    //packlenth
	gCMD[2] = 0x52;
	gCMD[3] = 0x45;
	gCMD[4] = 0x56;
	gCMD[5] = 0x45;
	gCMD[6] = 0x00;
	gCMD[7] = 0x00;
	gCMD[8] = 0x00;
    gCMD[9] = 0x00;

	ret = SendCMDandData(gCMD,10);

	if(!ret)
	{
		DisInformation(_T("Read Version Fail!"),1);
				Version =0;
	}
	else
	{
		if(GetSimpleCMD(gCMD,4))
		{
			  if((gCMD[0]&0xC0) == 0xC0)
			  {
				m_FTVersion.Format(_T("V%02d.%02d"),gCMD[2],gCMD[3]);
				Version = gCMD[2]*0x100+gCMD[3];
				msg_Verinfo = m_FTVersion;

				UpdateData(FALSE);
			  }
			  else
			  {
				  DisInformation(_T("Read Version Fail!"),1);
				  Version =0;

			  }
		}
		else
		{
			DisInformation(_T("Read Version Fail!"),1);
					Version =0;
		}
	}

	 progressstep = 100;  //test
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(progressstep);

//	m_Hid.CloseDevice();
	return Version;
}


void CDFUToolsDlg::CheckUpdate(DWORD Ver)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ	
	if(Ver < 0x02)
	{
		CString strQuery;
		strQuery.Format(_T("�̼��汾%X �ѹ��ڣ��Ƿ���£�"), Ver);		
		if ( IDNO == ::MessageBox(m_hWnd, strQuery, _T("�̼���������"), MB_ICONQUESTION | MB_YESNO) )
		{ 
			return;
		}
		OnBootfw();
	}
}


void CDFUToolsDlg::OnBootfw()
{
	MSG message;
	WCHAR sPath[255];
	CString exedir;
	DWORD dwSize=255;
	BYTE buf[64];
	BYTE GetMSG[64];

	if(dwFileLen==0) //�Ƿ��ȡ�����ļ�
	{
		MessageBox(_T("Update file don't exist "));
		return ;
	} 
	else
	{		
		DisInformation(_T("Boot Firmware......"),1);
		if(!OpenDevice())
			return ;
/***********��λAPP ��BootLoader����***************************************************************************/
		memset(buf,0,0x40);
		buf[0] = 0x20; //Boot Firmware Command
		buf[1] = 13;
		buf[2] = 0x42;
		buf[3] = 0x4F;
		buf[4] = 0x4F;
		buf[5] = 0x54;
		buf[6] = 0x52;
		buf[7] = 0x45;
		buf[8] = 0x53;
		buf[9] = 0x45;
		buf[10] = 0x54;
		buf[11] = 0x00;
		buf[12] = 0x00;

		BOOL ret = SendCMDandData(buf,13);
		if(!ret)
		{
			m_Hid.CloseDevice();	
			DisInformation(_T("USB Write fail!Boot Firmware fail!"),1);
			return;
		}

		if(GetSimpleCMD(GetMSG,4))
		{
              if((GetMSG[0]&0xC0) != 0xC0 )
			  {
				  m_Hid.CloseDevice();	
				  DisInformation(_T("MCU Requst Error!Boot Firmware fail!"),1);
				  return;

			  }
		}
		m_Hid.CloseDevice();	
/***********��ѯ�Ƿ�λ�ɹ�***************************************************************************/

		MessageBox(_T("�̼����£���Ҫ�Ͽ�usb���ӣ�"), _T("����"), MB_OK | MB_ICONEXCLAMATION);
		
        LONG T1 = GetTickCount();
		
		LONG T2 = GetTickCount();
		
		while(T2-T1<2000) //�ȴ�2��
		{
		  T2 = GetTickCount();
		}
				
		DWORD ver = GetFTVersion();
		if(ver != 0x0001)
		{
			m_Hid.CloseDevice();	
			DisInformation(_T("Reset Boot Firmware fail!"),1);
			return;
		}

/***********����APP����***************************************************************************/

		memset(buf,0,0x40);
		buf[0] = 0x21; //Erase APP
		buf[1] = 5;
		buf[2] = 120;
		buf[3] = 0;
		buf[4] = 0;
		ret = SendCMDandData(buf,5);
		if(!ret)
		{
			m_Hid.CloseDevice();
			DisInformation(_T("Erase APP fail!"),1);
			return;
		}

		if(GetSimpleCMD(GetMSG,4))
		{
			if((GetMSG[0]&0xC0) != 0xC0 )
			{
				m_Hid.CloseDevice();	
				DisInformation(_T("MCU Requst Error!Boot Firmware fail!"),1);
				return;

			}
		}
/***********дAPP����***************************************************************************/

		WriteApp();

/***********У��APP����***************************************************************************/

		VerifyApp();


		DisInformation(_T("Updata Firmware OK!"),1);

/***********��λ��λ��***************************************************************************/	
	
		DisInformation(_T("Reset Firmware......"),1);	
		
		memset(buf,0,0x40);
		buf[0] = 0x22; //Reset
		buf[1] = 4;
		buf[2] = 0;
		buf[3] = 0;

		ret = SendCMDandData(buf,4);
		if(!ret)
		{
			m_Hid.CloseDevice();
			DisInformation(_T("Boot Reset fail!"),1);
			return;
		}

		if(GetSimpleCMD(GetMSG,4))
		{
			if((GetMSG[0]&0xC0) != 0xC0 )
			{
				m_Hid.CloseDevice();	
				DisInformation(_T("MCU Requst Error!Boot Reset fail!"),1);
				return;

			}
		}
		
		DisInformation(_T("Reset Firmware SUCCESS!"),1);		
		
		int cntloop = 8000;
		while(cntloop--)
		{
			((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(100);
		}

		((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(0);//��ս�����

	}
}

BOOL CDFUToolsDlg::VerifyApp()
{

	int progressstep = 0;
    int Read_Address = 0;
    int filelength;	
    int cnt = 0;
	int READ_cnt = 0;
	BYTE buf[64];
	BYTE gCMD[64];
	BYTE index=0;
	
    DisInformation(_T("Verify Flash..."),1);
		
    filelength = dwFileLen;
    Read_Address = ApplicationAddress;

	while(filelength>0)
	{
		if(filelength>56)
			cnt = 56;
		else
			cnt = filelength;
		filelength -= cnt;
		
        buf[0] = 0x24;			
		buf[1] = 8 + cnt;
		buf[2] = (unsigned char )Read_Address&0x000000FF;
		buf[3] = (unsigned char )(Read_Address>>8)&0x000000FF;
		buf[4] = (unsigned char )(Read_Address>>16)&0x000000FF;
		buf[5] = (unsigned char )(Read_Address>>24)&0x000000FF;
		
		BOOL bRet = SendCMDandData(buf,0x40);	
		if(!bRet)
		{
				DisInformation(_T("USB Connect error! Verify Flash Fail!"),1);
			return FALSE;
		}

		bRet = GetSimpleCMD(gCMD,0x40);
		if(!bRet)	
		{
				DisInformation(_T("USB Connect error! Verify Flash Fail!"),1);
			return FALSE;
		}

		if((gCMD[0]&0xC0) != 0xC0)		
		{
				DisInformation(_T("MCU Requst Error! Verify Flash Fail!"),1);
			return FALSE; 
		}

		for(index=0;index<cnt;index++)
		{

		    if(gCMD[6+index] != WriteBuf[READ_cnt+index])
			{
				DisInformation(_T("Verify Flash Fail!"),1);
				return FALSE;
			}
				
		}
		
        READ_cnt = cnt + READ_cnt;
		Read_Address = Read_Address + cnt;
						
		((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(progressstep);
		progressstep = (dwFileLen-filelength)*100 /dwFileLen; //�������
	}

        DisInformation(_T("Verify Flash OK!"),1);
		
   return TRUE;
}

BOOL CDFUToolsDlg::WriteApp()
{
	int progressstep = 0;
    int Write_Address = 0;
    int filelength;	
    int cnt = 0;
	int WRITE_cnt = 0;
	BYTE buf[64];
	BYTE gCMD[2];
	BYTE index=0;
		
	//	unsigned char WriteBuf[256*1024];  //256K
	
	DisInformation(_T("Writing Flash..."),1);
	
    filelength = dwFileLen;
    Write_Address = ApplicationAddress;

	while(filelength>0)
	{
		if(filelength>56)
			cnt = 56;
		else
			cnt = filelength;
		filelength -= cnt;
		
        buf[0] = 0x23;			
		buf[1] = 8 + cnt;
		buf[2] = (unsigned char )Write_Address&0x000000FF;
		buf[3] = (unsigned char )(Write_Address>>8)&0x000000FF;
		buf[4] = (unsigned char )(Write_Address>>16)&0x000000FF;
		buf[5] = (unsigned char )(Write_Address>>24)&0x000000FF;
		
		for(index=0;index<cnt;index++)
		{
		  buf[6+index] = WriteBuf[WRITE_cnt+index];
		}
		
        WRITE_cnt = cnt + WRITE_cnt;
		Write_Address = Write_Address + cnt;
		
		BOOL bRet = SendCMDandData(buf,0x40);	
		if(!bRet)
		{
				DisInformation(_T("USB Connect error! Writing Flash Fail!"),1);
			return FALSE;
		}

		bRet = GetSimpleCMD(gCMD,2);
		if(!bRet)	
		{
				DisInformation(_T("USB Connect error! Writing Flash Fail!"),1);
			return FALSE;
		}

		if((gCMD[0]&0xC0) != 0xC0)		
		{
				DisInformation(_T("MCU Requst Error! Writing Flash Fail!"),1);
			return FALSE; 
		}

		((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(progressstep);
		progressstep = (dwFileLen-filelength)*100 /dwFileLen; //�������
	}

	DisInformation(_T("Write Flash OK!"),1);

	return TRUE;
}


void CDFUToolsDlg::CoverToDaDuan(BYTE *pData,int size)
{
	for(int i =0;i<size;i+=2)
	{
		BYTE HiBYTE = *(pData+1);
		BYTE LiBYTE = *pData;

		*pData = HiBYTE;
		*(pData+1) = LiBYTE;

		pData += 2;
	}

}

CString CDFUToolsDlg::GetFileNameFormPath(CString strFilePathName)
{
	if(strFilePathName.IsEmpty())
		return NULL;
	if(strFilePathName.Find('\\',0) == -1)
		return strFilePathName;
	CString strFileName;
	int pos = 0;
	int n = strFilePathName.GetLength();
	while(n >= 0)
	{
		wchar_t cone = strFilePathName.GetAt(--n);
		if(cone == '\\')
			break;
	}
	strFileName = strFilePathName.Right(strFilePathName.GetLength()-n-1);
	return strFileName;
}

void CDFUToolsDlg::GetFileNameASCII(BYTE *pASCIIData,CString strFilePath)
{
	int nFileNameLength;
	CString strFileName;

	strFileName = GetFileNameFormPath(strFilePath);
	nFileNameLength = strFileName.GetLength();

	if(nFileNameLength>16)
	{
		strFileName = strFileName.Left(11);//11+*.bin = 16���ַ�
		strFileName += _T("*.bin");
		nFileNameLength = strFileName.GetLength();
	}

	int i = 0;
	for(i = 0;i<nFileNameLength;i++)
	{
		wchar_t Onechar = strFileName.GetAt(i);
		*pASCIIData = Onechar;
		pASCIIData++;
	}
	while(i++<16)
	{
		*pASCIIData = 0x20;//����ո�
		pASCIIData++;
	}
}

void CDFUToolsDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ	
	KillTimer(1);
	DWORD ver = GetFTVersion();
	if(ver != 0)
		CheckUpdate(ver);
	//Sleep(1000);
	//Sleep(1000);
	//Sleep(1000);
	//Sleep(1000);
	m_Version = ver;

	CDialogEx::OnTimer(nIDEvent);
}


void CDFUToolsDlg::OnNMCustomdrawProgress1(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;
}


void CDFUToolsDlg::OnEnChangeEdit1()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialogEx::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
}


void CDFUToolsDlg::OnStnClickedStaticDrvver()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}


void CDFUToolsDlg::OnBnClickedCleardis()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	DisInformation(_T(""),0);
}


void CDFUToolsDlg::OnBnClickedOpenvcom()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}
