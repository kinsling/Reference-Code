#ifndef __IHIDUSB__H__20140619
#define __IHIDUSB__H__20140619

#include <windows.h>
#include <tchar.h>

struct IHidUsb 
{
	enum
	{
		ERR_TIMEOUT = 0,
		ERR_HANDLE = -1,
		ERR_UNKOWN = -2,
	
	};
	virtual BOOL OpenDevice(DWORD dwVentorId, DWORD dwProductId)			= 0; 
	virtual BOOL WriteData(const CHAR *lpszBuf, INT nSize, INT nTimeOut)	= 0;		// ʱ�䵥λΪs
	virtual INT ReadData(CHAR *lpszBuf, INT nSize, INT nTimeOut)			= 0;		// ʱ�䵥λΪs
	virtual VOID SetSigRW()													= 0;
	virtual VOID ResetSigRW()												= 0;
	virtual VOID CloseDevice()												= 0;
	virtual VOID ClearBuf()													= 0;
	virtual BOOL ReOpen()													= 0;
	virtual VOID Release()													= 0;
};

typedef VOID (*CreateObjectFunc)(IHidUsb **ppInstance);

class CHidUsbManager
{
public:
	CHidUsbManager()
	{
		m_lpInstance = NULL;
		m_hDll = NULL;
	}
	virtual ~CHidUsbManager()
	{
		if (m_lpInstance != NULL)
		{
			m_lpInstance->Release();
			m_lpInstance = NULL;

			FreeLibrary(m_hDll);
			m_hDll = NULL;
		}
	}

public:
	BOOL Create()
	{
		m_hDll = ::LoadLibrary(_T("IHidUsb.dll"));
		CreateObjectFunc CreateFunc;
		if (m_hDll != NULL)
		{
			CreateFunc = (CreateObjectFunc)GetProcAddress(m_hDll, "CreateObject");
			CreateFunc(&m_lpInstance);

			return TRUE;
		}

		return FALSE;
	}
	VOID Release();

public:
	HMODULE m_hDll;
	IHidUsb *m_lpInstance;
};

#endif 