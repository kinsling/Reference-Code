#pragma once

extern "C" {
#include <setupapi.h>
#include <dbt.h>
#include "hidsdi.h"


#include "hidsdi++.h"
#include "hid.h"
#include "setupapi.h"
#include "usb100.h"
}
// CHIDCmd

#define HID_MAX_PACKET_SIZE_EP 64
#define V6M_MAX_COMMAND_LENGTH (HID_MAX_PACKET_SIZE_EP - 2)

class CHIDCmd : public CWnd
{
	DECLARE_DYNAMIC(CHIDCmd)

public:
	CHIDCmd();
	virtual ~CHIDCmd();

	BOOL OpenDevice(USHORT usVID, USHORT usPID, USHORT usSVN);
	void CloseDevice();
	BOOL ReadFileCmd(unsigned char *pcBuffer, size_t szMaxLen, DWORD *pdwLength, DWORD dwMilliseconds);
	BOOL WriteFileCmd(unsigned char *pcBuffer, DWORD dwLen, DWORD *pdwLength, DWORD dwMilliseconds);

	int WriteTest();
	void Regist();
protected:
	BOOL ReadFile(char *pcBuffer, DWORD szMaxLen, DWORD *pdwLength, DWORD dwMilliseconds);
	BOOL WriteFile(const char *pcBuffer, DWORD szLen, DWORD *pdwLength, DWORD dwMilliseconds);
	BOOL OpenHidDevice(USHORT usVID, USHORT usPID, USHORT usSVN);
	void GetDeviceCapabilities();

public:
	HANDLE m_hReadHandle;
	HANDLE m_hWriteHandle;
	HANDLE m_hReadEvent;
	HANDLE m_hWriteEvent;
	//HANDLE m_hAbordEvent;
	HIDP_CAPS Capabilities;
protected:
	CHAR	m_acRdBuffer[HID_MAX_PACKET_SIZE_EP + 1];
	CHAR	m_acWtBuffer[HID_MAX_PACKET_SIZE_EP + 1];
protected:
	DECLARE_MESSAGE_MAP()
};


