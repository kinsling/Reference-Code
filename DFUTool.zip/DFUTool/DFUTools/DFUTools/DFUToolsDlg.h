


// DFUToolsDlg.h : ͷ�ļ�
//
#include "HIDCmd.h"

#pragma once

#define ApplicationAddress  0x08002000  ////APP addrress

#define USB_TIME_OUT    500

#define FLASHMAXSIZE 0x1000
#define EEPROMMAXSIZE 0x100
#define OPTIONMAXSIZE 0x20	//
#define ROLLINGGODEMAXSIZE 0x08

//#define FLASH_FILE_LENTH	0x810
#define FLASH_FILE_LENTH	0x4010 //
#define EEPROM_FILE_LENTH	0x100

#define PACKHEAD 0x14277050		//
#define OPTIONADR 0x4000

#define  MAX_FILE_LEN        256*1024   //�ļ���󳤶ȣ���������


//------------------------------------------------------------------------------------------------
#define VID 0x2F81
#define PID 0x7209
#define SVN 0x0200




// CDFUToolsDlg �Ի���
class CDFUToolsDlg : public CDialogEx
{
// ����
public:
	CDFUToolsDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_DFUTOOLS_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:

	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

	//�Խ�����

	CString ReadIniOneKey(UINT unSection, UINT unKey, CString iniFilename);
	BOOL ReadHEX(CString strFileName,BYTE *pData,int size);
	BOOL ReadBin(CString strFileName,BYTE *pData,int size);
	BOOL ReadFiletoBuffer(CString strFileName,BYTE *pData,int size,int Style);//��ȡ�ļ�
	int Toint(CString Imm,int radix);
	unsigned short CheckSum(BYTE *addr, BYTE count);
	BOOL GetSimpleCMD(BYTE *pCMD,BYTE Size);
	BOOL SendCMDandData(BYTE *pData,int packlth);//����BOOTFWʱ����
	BOOL OpenDevice();
	void CloseDevice();
	void DisInformation(CString strMessage,int type);
	DWORD  GetFTVersion();
	void CheckUpdate(DWORD Ver);
	void OnBootfw();
	BOOL WriteApp();
	BOOL VerifyApp();
	void CoverToDaDuan(BYTE *pData,int size);
	CString GetFileNameFormPath(CString strFilePathName);//ȡ���ļ���
	void GetFileNameASCII(BYTE *pASCIIData,CString strFilePath);//ȡ���ļ�����ASCII��

	////�Խ�����


public:
	afx_msg void OnBnClickedDownload();
	afx_msg void OnBnClickedLoad();
	afx_msg void OnEnChangeEditPath();
	afx_msg void OnBnClickedTest();
	afx_msg void OnBnClickedReadFwVer();

private:

	CString m_EditInformation;

	CHIDCmd m_Hid;
	int m_nFlashSize;
	CString m_FTVersion;
	DWORD m_Version;
	CWnd *m_pSub[2];
	unsigned char WriteBuf[256*1024];  //256K
	DWORD dwFileLen;

	//-------------------------------------------------

public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);

public:
	afx_msg void OnNMCustomdrawProgress1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnChangeEdit1();
	CString m_Info;
	afx_msg void OnStnClickedStaticDrvver();
	CString msg_Verinfo;
	afx_msg void OnBnClickedCleardis();
	afx_msg void OnBnClickedOpenvcom();
};
