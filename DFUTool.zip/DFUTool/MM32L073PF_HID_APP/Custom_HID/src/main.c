/******************** (C) COPYRIGHT 2009 MM32 ********************
* File Name          : main.c
* Author             : MCD Application Team
* Version            : V3.0.1
* Date               : 04/27/2009
* Description        : Custom HID demo main file
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MM32 SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "MM32L073PF.h"
#include "usb_lib.h"
#include "hw_config.h"
#include "usbio.h"
#include "usb_regs.h"

#include "usb_pwr.h"

#include "uart.h"
#include "bsp.h"
#include "led.h"
#include "pwm.h"
#include "tim2.h"
#include "usb_desc.h"
#include "string.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void Delay(__IO uint32_t nCount);

/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : main.
* Description    : main routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
// MM2L073PF  Application  0x08002000 -- 0x08020000 120K byte flash

#define ApplicationAddress  0x08002000   //APP addrress
#define VECTOR_SIZE  0xC0   //48*4=192 = 0xC0

extern u8 Flag_over;
extern u8 count;

extern uint8_t Flag_Receive;


int main(void)
{
	
	 u8 t;
  u16 data1,data2;//,data3,data4;
	
  memcpy((void*)0x20000000, (void*)ApplicationAddress, VECTOR_SIZE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG,ENABLE);
	SYSCFG_MemoryRemapConfig(SYSCFG_MemoryRemap_SRAM);
	
	
#if 0
	
	 data1=*(u32*)0x1ffe0000;//??Address???2????
	 data2=*(u32*)0x1ffe0002;//??Address???2????	
	
		if((data1 != 0x7F80)||(data2 != 0xFF00))//C
		{
			FLASH_Unlock();
			
			if((data1 != 0xFFFF)||(data2 != 0xFFFF))
			{
				FLASH_EraseAllPages();
				FLASH_EraseOptionBlock(0x1ffe0000);
			}

			FLASH_EnableReadOutProtection();

			FLASH_Lock();	
			
		}
		
#endif	

		

  Set_System();
	
	uart_initwBaudRate(115200);
	
	LED_Init();

  USB_Interrupts_Config();

  Set_USBClock();

  USB_Init();
	
  while(bDeviceState != CONFIGURED)  //�ȴ�USB��ʼ�����
	{			
	}
	TIM1_PWM_Init(1000-1,48-1);
	
	Tim2_UPCount_test(500-1,48-1);
	
	printf("Jump to APP SUCCESS\r\n");	

	printf("APP Ver 0x0002\r\n");
	
	Flag_over = 0;
	
  while (1)
  {
		
			if(Flag_Receive)
			{
					APP_Program();
          Flag_Receive = 0;	
			}
			
			if(Flag_over)																
		 	{	
        Flag_over = 0;				
				for(t=0;t<count;t++)
				{
					while((UART1->CSR&UART_IT_TXIEN)==0);//�ȴ����ͽ���
					UART1->TDR=UART_RX_BUF[t];    
				}
				while((UART1->CSR&UART_IT_TXIEN)==0);//�ȴ����ͽ���			
				count = 0;		
		  }	
			
	}	
	
}

/*******************************************************************************
* Function Name  : Delay
* Description    : Inserts a delay time.
* Input          : nCount: specifies the delay time length.
* Output         : None
* Return         : None
*******************************************************************************/
void Delay(__IO uint32_t nCount)
{
  for(; nCount!= 0;nCount--);
}

#ifdef  USE_FULL_ASSERT
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while(1)
  {
  }
}
#endif

/******************* (C) COPYRIGHT 2009 MM32 *****END OF FILE****/





