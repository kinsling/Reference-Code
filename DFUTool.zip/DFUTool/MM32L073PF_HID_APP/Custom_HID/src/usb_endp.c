/******************** (C) COPYRIGHT 2009 MM32 ********************
* File Name          : usb_endp.c
* Author             : MCD Application Team
* Version            : V3.0.1
* Date               : 04/27/2009
* Description        : Endpoint routines
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MM32 SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "platform_config.h"
#include "MM32L073PF.h"
#include "usb_lib.h"
#include "usb_istr.h"
#include "usbio.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
//uint8_t Receive_Buffer[BUFF_SIZE];

uint8_t Flag_Receive;
uint8_t Flag_Send;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : EP1_OUT_Callback.
* Description    : EP1 OUT Callback Routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP1_OUT_Callback(void)
{
//  BitAction Led_State;
	u8 ReadCnt;
  ReadCnt = USB->EP1_AVIL;   //��ǰ�˵���յ������ݸ���
  PMAToUserBufferCopy(USB_Receive_Buffer, ENDP1, ReadCnt);   //�Ѷ˵���յ�����copy���û�buff
	
	Flag_Receive = 1;
	
}



void EP2_IN_Callback(void)
{
	
	  Flag_Send = 0;
	
}

/******************* (C) COPYRIGHT 2009 MM32 *****END OF FILE****/

