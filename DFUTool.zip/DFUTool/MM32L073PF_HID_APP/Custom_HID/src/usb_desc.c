/******************** (C) COPYRIGHT 2009 MM32 ********************
* File Name          : usb_desc.c
* Author             : MCD Application Team
* Version            : V3.0.1
* Date               : 04/27/2009
* Description        : Descriptors for Custom HID Demo
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MM32 SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "usb_lib.h"
#include "usb_desc.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* USB标准设备描述符*/
const uint8_t CustomHID_DeviceDescriptor[CUSTOMHID_SIZ_DEVICE_DESC] =
{
    0x12,                       /*bLength：长度，设备描述符的长度为18字节*/
    USB_DEVICE_DESCRIPTOR_TYPE, /*bDescriptorType：类型，设备描述符的编号是0x01*/
    0x00,                       /*bcdUSB：所使用的USB版本为2.0*/
    0x02,
    0x00,                       /*bDeviceClass：设备所使用的类代码*/
    0x00,                       /*bDeviceSubClass：设备所使用的子类代码*/
    0x00,                       /*bDeviceProtocol：设备所使用的协议*/
    0x40,                       /*bMaxPacketSize：最大包长度为64字节*/
    0x81,
    0x2F,                       /* idVendor = 0x2F81 */
    0x09,
    0x72,                       /* idProduct = 0x7209 */
    0x00,                       /*bcdDevice：设备的版本号为2.00*/
    0x02,
    1,                          /*iManufacturer:厂商字符串的索引*/
    2,                          /*iProduct：产品字符串的索引*/
    3,                          /*iSerialNumber：设备的序列号字符串索引*/
    0x01                        /*bNumConfiguration：设备有1种配置*/
}; /* CustomHID设备描述符 */


/* USB配置描述符集合(配置、接口、端点、类、厂商)(Configuration, Interface, Endpoint, Class, Vendor */
const uint8_t CustomHID_ConfigDescriptor[CUSTOMHID_SIZ_CONFIG_DESC] =
{
    0x09, 		  /*bLength：长度，设备字符串的长度为9字节*/
    USB_CONFIGURATION_DESCRIPTOR_TYPE, 	/*bDescriptorType：类型，配置描述符的类型编号为0x2*/
    CUSTOMHID_SIZ_CONFIG_DESC,	   		/*wTotalLength：配置描述符的总长度为41字节*/    
    0x00,
    0x01,         /*bNumInterfaces：配置所支持的接口数量1个*/
    0x01,         /*bConfigurationValue：该配置的值*/
    0x00,         /*iConfiguration：该配置的字符串的索引值，该值为0表示没有字符串*/              
    0xC0,         /* bmAttributes:设备的一些特性，0xc0表示自供电，不支持远程唤醒
		     D7:保留必须为1，D6:是否自供电，D5：是否支持远程唤醒，D4~D0：保留设置为0*/
//    0x32,       /*从总线上获得的最大电流为100mA */
    0x96,         /*MaxPower：设备需要从总线上获取多少电流，单位为2mA，0x96表示300mA*/

    /**************  HID接口描述符****************/
    0x09,         /*bLength：长度，接口描述符的长度为9字节 */
    USB_INTERFACE_DESCRIPTOR_TYPE,/* bDescriptorType：接口描述符的类型为0x4 */
    0x00,         /*bInterfaceNumber：该接口的编号*/
    0x00,         /*bAlternateSetting：该接口的备用编号 */
	  0x02,         /*bNumEndpoints：该接口所使用的端点数,不包含端点0*/
    0x03,         /*bInterfaceClass该接口所使用的类为HID*/
    0x00,         /*bInterfaceSubClass：该接口所用的子类 1=BOOT, 0=no boot */
    0x00,         /*nInterfaceProtocol :该接口使用的协议0=none, 1=keyboard, 2=mouse */
    0,            /*iInterface: 该接口字符串的索引 */

    /*****************HID描述符 ********************/
    0x09,         /*bLength: HID描述符的长度为9字节 */
    HID_DESCRIPTOR_TYPE, /* bDescriptorType: HID的描述符类型为0x21 */
    0x10,         /*bcdHID: HID协议的版本为1.1 */
    0x01,
    0x00,         /*bCountryCode: 国家代号 */
    0x01,         /*bNumDescriptors: 下级描述符的数量*/
    0x22,         /*bDescriptorType：下级描述符的类型*/
    CUSTOMHID_SIZ_REPORT_DESC,/* wItemLength: 下一集描述符的长度*/
    0x00,

    /********************输入端点描述符******************/
    0x07,         /* bLength: 端点描述符的长度为7字节*/
    USB_ENDPOINT_DESCRIPTOR_TYPE, /* bDescriptorType: 端点描述符的类型为0x21*/
    0x82,         /* bEndpointAddress: 该端点(IN)的地址,D7:0(OUT),1(IN),D6~D4:保留,D3~D0:端点号*/               
    0x03,         /* bmAttributes: 端点的属性为为中断端点.
		     D0~D1表示传输类型:0(控制传输),1(等时传输),2(批量传输),3(中断传输)
		     非等时传输端点:D2~D7:保留为0
		     等时传输端点：
		     D2~D3表示同步的类型:0(无同步),1(异步),2(适配),3(同步)
		     D4~D5表示用途:0(数据端点),1(反馈端点),2(暗含反馈的数据端点),3(保留)，D6~D7:保留,*/
    0x40,         /* wMaxPacketSize: 该端点支持的最大包长度为64字节*/
    0x00,
    0x02,         /* bInterval: 轮询间隔(2 ms) */
    
	/********************输出端点描述符******************/	
    0x07,		  /* 端点描述符的长度为7字节 */
    USB_ENDPOINT_DESCRIPTOR_TYPE,	/* bDescriptorType: 端点描述符的类型为0x21*/
    0x01,		  /* bEndpointAddress: 该端点(OUT)的地址,D7:0(OUT),1(IN),D6~D4:保留,D3~D0:端点号*/
    0x03,		  /* bmAttributes: 端点的属性为为中断端点 */
    0x40,		  /* wMaxPacketSize: 该端点支持的最大包长度为64字节  */
    0x00,
    0x02,		  /* bInterval: 轮询间隔(2 ms) */
		
}; 

/* HID的报告描述符*/
const uint8_t CustomHID_ReportDescriptor[CUSTOMHID_SIZ_REPORT_DESC] = 
{ 
	0x05, 0x8c, /* USAGE_PAGE (ST Page) */ 
	0x09, 0x01, /* USAGE (Demo Kit) */ 
	0xa1, 0x01, /* COLLECTION (Application) */ 
	
	// The Input report 
	0x09,0x03, // USAGE ID - Vendor defined 
	0x15,0x00, // LOGICAL_MINIMUM (0) 
	0x26,0x00, 0xFF, // LOGICAL_MAXIMUM (255) 
	0x75,0x08, // REPORT_SIZE (8bit) 
	0x95,0x40, // REPORT_COUNT (64Byte) 
	0x81,0x02, // INPUT (Data,Var,Abs) 

	// The Output report 
	0x09,0x04, // USAGE ID - Vendor defined 
	0x15,0x00, // LOGICAL_MINIMUM (0) 
	0x26,0x00,0xFF, // LOGICAL_MAXIMUM (255) 
	0x75,0x08, // REPORT_SIZE (8bit) 
	0x95,0x40, // REPORT_COUNT (64Byte) 
	0x91,0x02, // OUTPUT (Data,Var,Abs) 

    0xc0 	          /*     END_COLLECTION	             */ 
}; 


/* 语言ID描述符 */
const uint8_t CustomHID_StringLangID[CUSTOMHID_SIZ_STRING_LANGID] =
{
    CUSTOMHID_SIZ_STRING_LANGID,   	/*bLength：本描述符的长度为4字节*/
    USB_STRING_DESCRIPTOR_TYPE,	   	/*bDescriptorType：字符串描述符的类型为0x03*/
    0x09,						   	/*bString：语言ID为0x0409，表示美式英语*/
    0x04
}; /* LangID = 0x0409: U.S. English*/

/*厂商字符串描述符*/
const uint8_t CustomHID_StringVendor[CUSTOMHID_SIZ_STRING_VENDOR] =
{
    CUSTOMHID_SIZ_STRING_VENDOR, 	/*bLength：厂商字符串描述符的长度*/
    USB_STRING_DESCRIPTOR_TYPE,  	/*bDescriptorType：字符串描述符的类型为0x03*/
    'M', 0,
	'i', 0,
	'n', 0,
	'd', 0,
	'M', 0,
	'o', 0,
	't', 0,
	'i', 0,
	'o', 0,
	'n', 0,
	' ', 0,
    'S', 0,
	'O', 0,
	'C', 0,
	' ', 0,
	'S', 0,
	'o', 0,
	'l', 0,
	'u', 0,
	't', 0,
	'i', 0,	
	'o', 0,
	'n', 0,	
	's', 0	 /*自定义*/ //MindMotion SOC Solutions	
};

/*产品的字符串描述符*/
const uint8_t CustomHID_StringProduct[CUSTOMHID_SIZ_STRING_PRODUCT] =
{
    CUSTOMHID_SIZ_STRING_PRODUCT,   /* bLength：产品的字符串描述符*/
    USB_STRING_DESCRIPTOR_TYPE,     /* bDescriptorType：字符串描述符的类型为0x03*/
    'M', 0,
	'M', 0,
	'3', 0,
	'2', 0,
	' ', 0,
	'C', 0,
	'u', 0,
	's', 0,
	't', 0,  
	'o', 0,
	'm', 0,	
	' ', 0,
	'H', 0, 
	'I', 0, 
	'D', 0 	/*自定义*/ //MM32 Custom HID	
};

/*产品序列号的字符串描述符*/
uint8_t CustomHID_StringSerial[CUSTOMHID_SIZ_STRING_SERIAL] =
{
    CUSTOMHID_SIZ_STRING_SERIAL,    /* bLength：产品序列号*/
    USB_STRING_DESCRIPTOR_TYPE,     /* bDescriptorType：字符串描述符的类型为0x03*/
    'M', 0,
	'M', 0,
	'3', 0,
	'2', 0,
	'L', 0,
	'0', 0,
	'7', 0,
	'3', 0,
	'P', 0,
	'F', 0  /*自定义*/ //MM32L073PF
};

