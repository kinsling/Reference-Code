#include "bsp.h"
#include "HAL_flash.h"

/********************************************************************************************************
**������Ϣ ��                   
**�������� ��
**������� ����
**������� ����
********************************************************************************************************/

void APP_Program(void)
{
		 uint8_t CMD=0;
	
			  CMD = USB_Receive_Buffer[0];
				switch(CMD)
				{
					case 0x00: //�ظ��汾��

						 if((USB_Receive_Buffer[2] == 0x52)&&(USB_Receive_Buffer[3] == 0x45)&&(USB_Receive_Buffer[4] == 0x56)&&(USB_Receive_Buffer[5] == 0x45))
						 {
							 
							USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;
							USB_Send_Buffer[1] = USB_Receive_Buffer[1];
							USB_Send_Buffer[2] = 0x00;
							USB_Send_Buffer[3] = 0x02;    //Bootloader  Ver:00.02
							USB_Send_Buffer[4] = 0;
							USB_Send_Buffer[5] = 0;		 
							USB_Send_Buffer[6] = 0;
							USB_Send_Buffer[7] = 0;		 
							USB_Send_Buffer[8] = 0;
							USB_Send_Buffer[9] = 0;	
							 
							USB_SendData(USB_Send_Buffer,0x40);		 
							 
						 }
						 else
						 {
							memset(USB_Send_Buffer,0,0x40);
							USB_SendData(USB_Send_Buffer,0x40);		
							 
						 }
					
					break;
						 
					case 0x20:  //��λ��BootLoader
					
								 if((USB_Receive_Buffer[2] == 0x42)&&(USB_Receive_Buffer[3] == 0x4F)&&(USB_Receive_Buffer[4] == 0x4F)//
									 &&(USB_Receive_Buffer[5] == 0x54)&&(USB_Receive_Buffer[6] == 0x52)&&(USB_Receive_Buffer[7] == 0x45)//
									 &&(USB_Receive_Buffer[8] == 0x53)&&(USB_Receive_Buffer[9] == 0x45)&&(USB_Receive_Buffer[10] == 0x54))
								 {	
								
											 USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;  
											 USB_Send_Buffer[1] = USB_Receive_Buffer[1];				 
											 USB_SendData(USB_Send_Buffer,0x40);	
									 
											 FLASH_Unlock();   
											 FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
											 FLASH_ErasePage(0x08001C00);

											 FLASH_Lock();
											
											 PowerOff();
										//   __set_FAULTMASK(1);      // �ر������ж�
											 NVIC_SystemReset();  // ��λ
								 }
								 else
								 {
									 
									memset(USB_Send_Buffer,0,0x40);
									USB_SendData(USB_Send_Buffer,0x40);		
									 
								 }	
								 
					   break;
							
					case 0x01:  //����ָ��
						
								USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xC0;  //0xC0
								USB_Send_Buffer[1] = USB_Receive_Buffer[1];
								USB_Send_Buffer[2] = 0x55;
								USB_Send_Buffer[3] = 0xaa;
								USB_Send_Buffer[4] = 0x55;
								USB_Send_Buffer[5] = 0xaa;
								USB_SendData(USB_Send_Buffer,64); 					
						
					break;
					
					default:
						
					
					
					break;
								 
								 
					
				}
					
				memset(USB_Receive_Buffer,0,0x40);	
	
	
	
	
}



/**
* @brief  Erases the FLASH option bytes.
* @param  None
* @retval : FLASH Status: The returned value can be: FLASH_BUSY, 
*   FLASH_ERROR_PG, FLASH_ERROR_WRP, FLASH_COMPLETE or 
*   FLASH_TIMEOUT.
*/
FLASH_Status FLASH_EraseOptionBlock(unsigned int u32addressBase)
{
    FLASH_Status status = FLASH_COMPLETE;
    
    FLASH->AR = u32addressBase;
    
    /* Wait for last operation to be completed */
    status = FLASH_WaitForLastOperation(EraseTimeout);
    if(status == FLASH_COMPLETE)
    {
        /* Authorize the small information block programming */
        FLASH->OPTKEYR = FLASH_KEY1;
        FLASH->OPTKEYR = FLASH_KEY2;
        
        /* if the previous operation is completed, proceed to erase the option bytes */
        FLASH->CR |= CR_OPTER_Set;
        FLASH->CR |= CR_STRT_Set;
        /* Wait for last operation to be completed */
        status = FLASH_WaitForLastOperation(EraseTimeout);
        
        if(status == FLASH_COMPLETE)
        {
            /* if the erase operation is completed, disable the OPTER Bit */
            FLASH->CR &= CR_OPTER_Reset;
            
            {
                /* if the program operation is completed, disable the OPTPG Bit */
                FLASH->CR &= CR_OPTPG_Reset;
            }
        }
        else
        {
            if (status != FLASH_BUSY)
            {
                /* Disable the OPTPG Bit */
                FLASH->CR &= CR_OPTPG_Reset;
            }
        }  
    }
    
    /* Return the erase status */
    return status;
}


FLASH_Status FLASH_ProgramOptionHalfWord(unsigned int u32addressBase,unsigned int u32addressoffset,unsigned short u16Data)
{
  FLASH_Status status = FLASH_COMPLETE;
  /* Check the parameters */
  assert_param(IS_FUNCTIONAL_STATE(NewState));

  status = FLASH_WaitForLastOperation(EraseTimeout);
  if(status == FLASH_COMPLETE)
  {
      /* Authorize the FPEC Access */
    FLASH->KEYR = FLASH_KEY1;
    FLASH->KEYR = FLASH_KEY2;
	  
    /* Authorizes the small information block programming */
    FLASH->OPTKEYR = FLASH_KEY1;
    FLASH->OPTKEYR = FLASH_KEY2;

	/* if the program operation is completed, disable the OPTPG Bit */

	if(0xffff!=*(u16*)(u32addressBase+u32addressoffset))//??????? //0x1ffe0000
	{
		FLASH_EraseOptionBlock(u32addressBase);
	}
	{
		FLASH->CR &= CR_OPTPG_Reset;
		  /* Enables the Option Bytes Programming operation */
		FLASH->CR |= CR_OPTPG_Set; 
		*(__IO uint16_t*)(u32addressBase+u32addressoffset) =u16Data;//0x01FE;//0x00FF;//0x807F;//0x817E;// 0x7E81;//0x807F;//
		
		/* Wait for last operation to be completed */
		status = FLASH_WaitForLastOperation(ProgramTimeout);
		if(status == FLASH_COMPLETE)
		{
		}
		else{
			if(status != FLASH_BUSY)
			{
				/* if the program operation is completed, disable the OPTPG Bit */
				FLASH->CR &= CR_OPTPG_Reset;
				/* Enables the Option Bytes Programming operation */
			}
		}
	}
  }

  /* Return the protection operation Status */
  return status;      
}



void FLASH_EnableReadOutProtection(void)
{
	FLASH_ProgramOptionHalfWord(0x1ffff800,0,0x807F);
	FLASH_ProgramOptionHalfWord(0x1ffe0000,0,0x7F80);
	FLASH_ProgramOptionHalfWord(0x1ffe0000,2,0xFF00);
	
}






