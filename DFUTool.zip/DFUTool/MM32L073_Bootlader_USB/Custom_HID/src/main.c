/******************** (C) COPYRIGHT 2009 MM32 ********************
* File Name          : main.c
* Author             : MCD Application Team
* Version            : V3.0.1
* Date               : 04/27/2009
* Description        : Custom HID demo main file
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MM32 SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "MM32L073PF.h"
#include "usb_lib.h"
#include "hw_config.h"
#include "usbio.h"
#include "usb_regs.h"

#include "usb_pwr.h"

//#include "uart.h"

#include "usb_desc.h"

#include "dfu_mal.h"
#include "Boot.h"
#include "platform_config.h"

//#include "core_cmFunc.h"

#include "HAL_syscfg.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void Delay(__IO uint32_t nCount);

/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : main.
* Description    : main routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
/******************************************************************************
// MM32L073PF 128K flash
Bootloader 0x08000000 -- 0x08001BFF  total 7K byte flash
Bootloader Flag  0x08001C00  need 1K
Application  0x08002000 -- 0x08020000  total 120K byte flash

*******************************************************************************/

#define VECTOR_SIZE  0xC0   //48*4=192 = 0xC0

extern uint8_t Flag_Receive;

uint16_t DFU_state;
typedef  void (*pFunction)(void);

pFunction Jump_To_Application;
uint32_t JumpAddress;


int main(void)
{


  DFU_state = 0;
	Set_System();            //ϵͳʱ�ӳ�ʼ��
  DFU_state = DFU_read_state();
	
	if( DFU_state == 0x0000 )   // ��ȡBootloader Flag 
	{

		PowerOff();
		
		USB_Cable_Config(DISABLE);          //USB����1.5K�ڲ���������
	
			/* Test if user code is programmed starting from address "ApplicationAddress" */
			
			if(((*(__IO uint32_t*)ApplicationAddress) & 0x2FFE0000 ) == 0x20000000)	//���ջ����ַ�Ƿ�Ϸ�
			{
				/* Jump to user application */ 
				JumpAddress = *(__IO uint32_t*) (ApplicationAddress + 4);
				Jump_To_Application = (pFunction) JumpAddress;

				/* Initialize user application's Stack Pointer */ 
				__set_MSP(*(__IO uint32_t*) ApplicationAddress);
				
				//Jump to APP
				Jump_To_Application();	
			}	
		
	}



	
//  Set_System();
	
//	uart_initwBaudRate(9600);

  USB_Interrupts_Config();

  Set_USBClock();

  USB_Init();
	
  while(bDeviceState != CONFIGURED)  //�ȴ�USB��ʼ�����
	{			
	}
		
  Bootloader_Erase_APP(); //��ֹ���򱻶��� ����BootLoader ������ǰ��APP�������
	
  while (1)
  {
     APP_Update();		
	}	
	
}

/*******************************************************************************
* Function Name  : Delay
* Description    : Inserts a delay time.
* Input          : nCount: specifies the delay time length.
* Output         : None
* Return         : None
*******************************************************************************/
void Delay(__IO uint32_t nCount)
{
  for(; nCount!= 0;nCount--);
}

#ifdef  USE_FULL_ASSERT
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while(1)
  {
  }
}
#endif

/******************* (C) COPYRIGHT 2009 MM32 *****END OF FILE****/
