#include "Boot.h"
#include "dfu_mal.h"
#include "usb_type.h"
#include "usb_conf.h"
#include "usb_type.h"
#include "usbio.h"
//#include "main_dfu.h"
#include "dfu_mal.h"
//#include "usb_pwr.h"
#include "hw_config.h"

#include "MM32L073PF.h"
#include "platform_config.h"
#include "Usb_desc.h"
#include "string.h"
#include "usb_pwr.h"

//#include "core_cmFunc.h"

extern uint8_t Flag_Receive;
extern uint8_t Flag_Send;

uint8_t LEN = 0;

/*************************************************************************************************************************/

void Clear_USB_Receive_Buffer(void)
{
	memset(USB_Receive_Buffer,0,64);
 }
 
 void Clear_USB_Send_Buffer(void)
{
	memset(USB_Send_Buffer,0,64);
}


/*************Check calculation********************************/

unsigned short CheckSum(uint8_t *addr, uint8_t count)
{
    register int sum = 0;

		while( count > 0 ) 
		{
		 sum =sum+*addr;
				 addr++;
		 count --;
		}

	   while (sum>>16)//当和的高16位不为0，把高16位作为校验和的一部分求和，
	   sum = (sum & 0xffff) + (sum >> 16);

	  return (short)~sum;
}


/**********校验Checksum*******************/

uint8_t Check_data(void)
{
	uint8_t Flag_check=0;
	uint16_t tmp_Checksum=0;
	uint8_t temp1,temp2;
	
	tmp_Checksum = CheckSum(USB_Receive_Buffer,USB_Receive_Buffer[1]-2);
	
	temp1 = tmp_Checksum&0x00FF;
	temp2 = (tmp_Checksum>>8)&0x00FF;	
	
	if( (temp2 != USB_Receive_Buffer[USB_Receive_Buffer[1]-2]) || (temp1 != USB_Receive_Buffer[USB_Receive_Buffer[1]-1]))
	{
		Flag_check = 1;
	}
	
	return Flag_check;
}
/*************************************************************************************************************************/

void Bootloader_Erase_APP(void)
{
   uint32_t Address;
   uint8_t index,temp;	
	     temp = APP_SIZE;
			 Address = 0x08002000;     // APP flash   0x08002000 -- 0x08020000  0x1E000  120K flash
			 FLASH_Unlock();  
			 FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
			 for(index=0;index<temp;index++ )
				{   	
				 FLASH_ErasePage(Address);
				 Address = Address + 0x400;   
				}
			 FLASH_Lock();
	


}
	
/*************************************************************************************************************************/

void Boot_MAL_Erase_app()     //
{
   uint32_t Address;
   uint8_t index,temp;
	 uint8_t Irq=0;
	 Irq = Check_data();
	 if(Irq)
	 {
	  memset(USB_Send_Buffer,0,0x40);
		USB_SendData(USB_Send_Buffer,LEN);	
	 }
   else
   {	
	
			 temp = USB_Receive_Buffer[2];  //APP erase size
			 Address = 0x08002000;     // APP flash   0x08002000 -- 0x08020000  0x1E000
			 FLASH_Unlock();  
			 FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
			 for(index=0;index<temp;index++ )
				{   	
				 FLASH_ErasePage(Address);
				 Address = Address + 0x400;   
				}
			 FLASH_Lock();
			 USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xC0;
			 USB_SendData(USB_Send_Buffer,LEN);
	 }
		
}



void FLASH_WriteByte(uint32_t addr , uint8_t *p , uint16_t Byte_Num)
{
	uint32_t HalfWord;
	Byte_Num = Byte_Num/2;
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	while(Byte_Num --)
	{
		HalfWord=*(p++);
		HalfWord|=*(p++)<<8;
	//	MAL_Write(addr, HalfWord);
		addr += 2;
	}
	FLASH_Lock();
}



void DFU_MAL_Write_onebulk()

{
	uint32_t HalfWord;
//  uint8_t  *writeBuff=NULL;	
  uint16_t  temp ,writeNumber;
  uint32_t WriteAddress;
	


	writeNumber = USB_Receive_Buffer[1];
	writeNumber = writeNumber - 8;
	writeNumber = writeNumber/2;
  WriteAddress = ((USB_Receive_Buffer[5]<<24)+(USB_Receive_Buffer[4]<<16)+(USB_Receive_Buffer[3]<<8)+USB_Receive_Buffer[2]);
	
  FLASH_Unlock();
  FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	for(temp=0;temp<writeNumber;temp++)
	{
		 HalfWord =  USB_Receive_Buffer[(2*temp)+6];
		 HalfWord = HalfWord | (USB_Receive_Buffer[(2*temp)+7]<<8);
		 FLASH_ProgramHalfWord(WriteAddress, HalfWord);
		 WriteAddress = WriteAddress + 2;
	}
			 
  FLASH_Lock();
	USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;	
  USB_Send_Buffer[1] = USB_Receive_Buffer[1];
	USB_SendData(USB_Send_Buffer,LEN); 
    
}


void Clear_DFU_State()
{
	
				 uint8_t Irq=0;
				 Irq = Check_data();
				 if(Irq)
				 {
					memset(USB_Send_Buffer,0,0x40);
					USB_SendData(USB_Send_Buffer,LEN);	
				 }
				 else
				 { 		
	
							 FLASH_Unlock();
							 FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
							 FLASH_ErasePage(0x08001C00);
//							 FLASH_ProgramHalfWord(0x08001C00, 0xFFFF);
							 FLASH_Lock();
							 USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;	
							 USB_Send_Buffer[1] = USB_Receive_Buffer[1];
							 USB_SendData(USB_Send_Buffer,LEN); 					 
				 }
				 
}


void DFU_MAL_Read()
{
  uint8_t  *readBuff=NULL;	
  uint32_t  temp,ReadNumber;
  uint32_t  ReadAddress;

	USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;
	USB_Send_Buffer[1] = USB_Receive_Buffer[1];
  USB_Send_Buffer[2] = USB_Receive_Buffer[2];
  USB_Send_Buffer[3] = USB_Receive_Buffer[3];
	USB_Send_Buffer[4] = USB_Receive_Buffer[4];
	USB_Send_Buffer[5] = USB_Receive_Buffer[5];
	
  ReadNumber = USB_Receive_Buffer[1];
	ReadNumber = ReadNumber - 8;
  ReadAddress = ((USB_Receive_Buffer[5]<<24)+(USB_Receive_Buffer[4]<<16)+(USB_Receive_Buffer[3]<<8)+USB_Receive_Buffer[2]); 	
  readBuff = MAL_Read (ReadAddress, ReadNumber);
	
	 for(temp=0;temp<ReadNumber;temp++)
	 {	
		USB_Send_Buffer[6+temp]   = (*(readBuff+temp))&0xff;
	 }
	 
	 USB_SendData(USB_Send_Buffer,LEN);  
}


void Setting_flags()
{ 

   FLASH_Unlock();   
   FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
   FLASH_ErasePage(0x08001C00);
   FLASH_ProgramHalfWord(0x08001C00, 0x0000);
   FLASH_Lock(); 
}




void DFU_writeoneword_state()
{   
   FLASH_Unlock();   
   FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	 FLASH_ErasePage(0x08001C00);
   FLASH_ProgramHalfWord(0x08001C00, 0x0000);
   FLASH_Lock();   
   USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;	
   USB_SendData(USB_Send_Buffer,LEN);

}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//

uint16_t DFU_read_state()
{
	uint8_t  *Buff = NULL;
	  
	uint16_t ReadDATA = 0;

	Buff = MAL_Read (0x08001C00, 2);  //DFU Flag  0x08001C00

	ReadDATA = (Buff[1]<<8)+Buff[0];

	return ReadDATA;
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//

void DFU_read_state_UP()
{

  uint8_t  *Buff = NULL;	
  uint32_t  temp;

  USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;
  
   Buff = MAL_Read (0x08001C00, 2);	
 
	 for(temp=0;temp<2;temp++)
	 {	
		USB_Send_Buffer[1+temp]  = (*(Buff+temp))&0xff;
	 }
	 
   USB_SendData(USB_Send_Buffer,LEN);  
}




void Write_BOOT_Data()
{
		 uint8_t Irq=0;
	 Irq = Check_data();
	 if(Irq)
	 {
	    memset(USB_Send_Buffer,0,0x40);
		  USB_SendData(USB_Send_Buffer,LEN);	
	 }
	 else
	 { 	
      DFU_MAL_Write_onebulk();
	 }
}


void Reset_Boot_Firmware()
{
	
	 uint8_t Irq=0;
	 Irq = Check_data();
	 if(Irq)
	 {
	  memset(USB_Send_Buffer,0,0x40);
		USB_SendData(USB_Send_Buffer,LEN);	
	 }
	 else
	 { 	

			 USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;   
			 USB_SendData(USB_Send_Buffer,LEN);	
			 Setting_flags();	
			 // Disconnect_the_USB();
			 USB_Cable_Config(DISABLE); 	
			 PowerOff();	
		//   __set_FAULTMASK(1);      // ¹Ø±ÕËùÓÐÖÐ¶Ï
			 NVIC_SystemReset();  // ¸´Î»

	 }
	 
}

void Boot_Firmware()  
{
	
	 uint8_t Irq=0;
	 Irq = Check_data();
	 if(Irq)
	 {
	  memset(USB_Send_Buffer,0,0x40);
		USB_SendData(USB_Send_Buffer,LEN);	
	 }
	 else
	 { 
	 
			 if((USB_Receive_Buffer[2] == 0x42)&&(USB_Receive_Buffer[3] == 0x4F)&&(USB_Receive_Buffer[4] == 0x4F)//
				 &&(USB_Receive_Buffer[5] == 0x54)&&(USB_Receive_Buffer[6] == 0x52)&&(USB_Receive_Buffer[7] == 0x45)//
				 &&(USB_Receive_Buffer[8] == 0x53)&&(USB_Receive_Buffer[9] == 0x45)&&(USB_Receive_Buffer[10] == 0x54))
			 {	
			
						 USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;  
			       USB_Send_Buffer[1] = USB_Receive_Buffer[1];				 
						 USB_SendData(USB_Send_Buffer,LEN);	
				 
						 FLASH_Unlock();   
						 FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
						 FLASH_ErasePage(0x08001C00);

						 FLASH_Lock();
						
						 //Disconnect_the_USB();
						 USB_Cable_Config(DISABLE); 

						 PowerOff();
					//   __set_FAULTMASK(1);      // ¹Ø±ÕËùÓÐÖÐ¶Ï
						 NVIC_SystemReset();  // ¸´Î»
			 }
			 else
			 {
				memset(USB_Send_Buffer,0,0x40);
				USB_SendData(USB_Send_Buffer,LEN);		
				 
			 }
		}
	 
}

void Verify_Boot_Firmware()
{
	
	 uint8_t Irq=0;
	 Irq = Check_data();
	 if(Irq)
	 {
	    memset(USB_Send_Buffer,0,0x40);
		  USB_SendData(USB_Send_Buffer,LEN);	
	 }
	 else
	 {
      DFU_MAL_Read();
	 }
}

void Reply_version_number()
{ 
	 uint8_t Irq=0;
	 Irq = Check_data();
	 if(Irq)
	 {
	  memset(USB_Send_Buffer,0,0x40);
		USB_SendData(USB_Send_Buffer,LEN);	
	 }
	 else
	 {
	 
		 if((USB_Receive_Buffer[2] == 0x52)&&(USB_Receive_Buffer[3] == 0x45)&&(USB_Receive_Buffer[4] == 0x56)&&(USB_Receive_Buffer[5] == 0x45))
		 {
			 
			USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;
			USB_Send_Buffer[1] = USB_Receive_Buffer[1];
			USB_Send_Buffer[2] = 0x00;
			USB_Send_Buffer[3] = 0x01;    //Bootloader  默认Ver:00.01 版本号
			USB_Send_Buffer[4] = 0;
			USB_Send_Buffer[5] = 0;		 
			USB_Send_Buffer[6] = 0;
			USB_Send_Buffer[7] = 0;		 
			USB_Send_Buffer[8] = 0;
			USB_Send_Buffer[9] = 0;	
			 
			USB_SendData(USB_Send_Buffer,LEN);		 
			 
		 }
		 else
		 {
			memset(USB_Send_Buffer,0,0x40);
			USB_SendData(USB_Send_Buffer,LEN);		
			 
		 }
		 
	 }

}


void Reset_Firmware()
{
 	 USB_Send_Buffer[0] = USB_Receive_Buffer[0] | 0xc0;   
   USB_SendData(USB_Send_Buffer,LEN);	

   //Disconnect_the_USB();
	 USB_Cable_Config(DISABLE); 
	
   PowerOff();
//   __set_FAULTMASK(1);      // ¹Ø±ÕËùÓÐÖÐ¶Ï
   NVIC_SystemReset();  // ¸´Î»
}


void APP_Update(void)
{
	  uint8_t host_cmd = 0;


    Flag_Send = 0;
	if(Flag_Receive)
		{

		 Flag_Receive=0;
     Clear_USB_Send_Buffer();			
 		 LEN = USB_Receive_Buffer[1];
		 host_cmd = USB_Receive_Buffer[0];
             
 			switch(host_cmd)        // Call correct subroutine to handle each kind of
			{                             // standard request
				  case 0x00:
          Reply_version_number();  //回复当前software 版本号
					break;
				
				  case 0x20:
					Boot_Firmware();         //擦除标志位并复位  //和APP程序同一条指令
				  break;
				 
				  case 0x21:
					Boot_MAL_Erase_app();    //Boot模式下擦除APP程序区数据
					break;
					
				  case 0x22:
					Reset_Boot_Firmware();   //APP校验正确写好Boot标志位并复位系统
					break;
					
				  case 0x23:
				  Write_BOOT_Data();       //Boot模式下写APP程序
					break;
					
			    case 0x24:
 		      Verify_Boot_Firmware();  //校验Boot程序数据
					break;

					case 0x25:
			    Clear_DFU_State();       //清除Boot标志位
					break;
  
				  //*************************************/
          // 调试指令
					
				  case 0x31:
		      DFU_read_state_UP();     //读Boot标志位
					break;
					
				  case 0x32:
			    DFU_writeoneword_state(); //写标志位
					break;
									
				  case 0x33:
				  Reset_Firmware();         //在Boot升级模式下复位系统
				  break;				
					
				  default:
						// unknow command, do nothing.
					break;
				} 

		}
    
		Clear_USB_Send_Buffer();
		
}




/***************************end of file****************************************************/



