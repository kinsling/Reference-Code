/******************** (C) COPYRIGHT 2009 MM32 ********************
* File Name          : usb_desc.h
* Author             : MCD Application Team
* Version            : V3.0.1
* Date               : 04/27/2009
* Description        : Descriptor Header for Custom HID Demo
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MM32 SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USB_DESC_H
#define __USB_DESC_H

#include "MM32L073PF.h"

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported define -----------------------------------------------------------*/

#define wTransferSize               0x0400   /* wTransferSize   = 1024 bytes */



//usb_desc.c文件中涉及到的一些宏定义都在usb_desc.h中有定义，如下
#define USB_DEVICE_DESCRIPTOR_TYPE              0x01   //设备描述符类型
#define USB_CONFIGURATION_DESCRIPTOR_TYPE       0x02   //配置描述符类型
#define USB_STRING_DESCRIPTOR_TYPE              0x03   //字符串描述符类型
#define USB_INTERFACE_DESCRIPTOR_TYPE           0x04   //接口描述符类型
#define USB_ENDPOINT_DESCRIPTOR_TYPE            0x05   //端点描述符类型

#define HID_DESCRIPTOR_TYPE                     0x21   //HID描述符类型
#define CUSTOMHID_SIZ_HID_DESC                  0x09   //HID描述符的长度
#define CUSTOMHID_OFF_HID_DESC                  0x12   //HID描述符在配置描述符集合数组中的偏移

#define CUSTOMHID_SIZ_DEVICE_DESC               18	   //设备描述符的长度
#define CUSTOMHID_SIZ_CONFIG_DESC               41	   //配置描述符的长度
#define CUSTOMHID_SIZ_REPORT_DESC               33 	   //报告描述符的的长度
#define CUSTOMHID_SIZ_STRING_LANGID             4	     //语言ID字符串描述符的长度
#define CUSTOMHID_SIZ_STRING_VENDOR             60  	 //厂商字符串描述符的长度
#define CUSTOMHID_SIZ_STRING_PRODUCT            33	   //产品字符串描述符的长度
#define CUSTOMHID_SIZ_STRING_SERIAL             32	   //序列号字符串描述符的长度

#define STANDARD_ENDPOINT_DESC_SIZE             0x09   

#define	REPORT_COUNT				64	   //端点长度

/* Exported functions ------------------------------------------------------- */
extern const uint8_t CustomHID_DeviceDescriptor[CUSTOMHID_SIZ_DEVICE_DESC];	 //设备描述符
extern const uint8_t CustomHID_ConfigDescriptor[CUSTOMHID_SIZ_CONFIG_DESC];	 //配置描述符
extern const uint8_t CustomHID_ReportDescriptor[CUSTOMHID_SIZ_REPORT_DESC];	 //报告描述符
extern const uint8_t CustomHID_StringLangID[CUSTOMHID_SIZ_STRING_LANGID];	 //语言ID字符串描述符
extern const uint8_t CustomHID_StringVendor[CUSTOMHID_SIZ_STRING_VENDOR];	 //厂商字符串描述符
extern const uint8_t CustomHID_StringProduct[CUSTOMHID_SIZ_STRING_PRODUCT];	 //产品字符串描述符
extern uint8_t CustomHID_StringSerial[CUSTOMHID_SIZ_STRING_SERIAL];		 //序列号字符串描述符



#endif /* __USB_DESC_H */

/******************* (C) COPYRIGHT 2009 MM32 *****END OF FILE****/
